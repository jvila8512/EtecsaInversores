# IMPLEMENTACIÓN TÉCNICA: FELICITY SOLAR MONITOR
## Ejemplos de Código y Guías de Desarrollo

---

## PARTE 1: BACKEND SPRING BOOT

### 1.1 Configuración de Modbus RTU

```java
// src/main/java/com/felicity/protocol/ModbusRTU.java
package com.felicity.protocol;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.util.Arrays;

public class ModbusRTU {
    
    private static final int CRC_POLY = 0xA001;
    private static final int TIMEOUT_MS = 2000;
    
    private InputStream input;
    private OutputStream output;
    
    public ModbusRTU(InputStream input, OutputStream output) {
        this.input = input;
        this.output = output;
    }
    
    /**
     * Leer múltiples registros holding (Función 03)
     * @param slaveId ID esclavo Modbus (normalmente 0x01)
     * @param startAddress Dirección inicial (ej: 0x1108 = 4361)
     * @param quantity Cantidad de registros a leer
     * @return Array de valores de 16 bits
     */
    public int[] readHoldingRegisters(
            int slaveId, 
            int startAddress, 
            int quantity) throws IOException {
        
        // Construir comando
        byte[] request = new byte[6];
        request[0] = (byte) slaveId;
        request[1] = 0x03; // Función: Read Holding Registers
        request[2] = (byte) ((startAddress >> 8) & 0xFF);
        request[3] = (byte) (startAddress & 0xFF);
        request[4] = (byte) ((quantity >> 8) & 0xFF);
        request[5] = (byte) (quantity & 0xFF);
        
        // Agregar CRC
        byte[] command = addCRC(request);
        
        // Enviar comando
        output.write(command);
        output.flush();
        
        // Leer respuesta
        byte[] response = readResponse(1 + 1 + 1 + quantity * 2 + 2); // Longitud esperada
        
        // Validar CRC
        if (!validateCRC(response)) {
            throw new IOException("CRC check failed");
        }
        
        // Parsear registros
        int[] registers = new int[quantity];
        int offset = 2; // Saltar slave ID y función
        for (int i = 0; i < quantity; i++) {
            registers[i] = ((response[offset] & 0xFF) << 8) | 
                          (response[offset + 1] & 0xFF);
            offset += 2;
        }
        
        return registers;
    }
    
    /**
     * Escribir un registro individual (Función 06)
     */
    public void writeSingleRegister(
            int slaveId, 
            int address, 
            int value) throws IOException {
        
        byte[] request = new byte[6];
        request[0] = (byte) slaveId;
        request[1] = 0x06; // Función: Write Single Register
        request[2] = (byte) ((address >> 8) & 0xFF);
        request[3] = (byte) (address & 0xFF);
        request[4] = (byte) ((value >> 8) & 0xFF);
        request[5] = (byte) (value & 0xFF);
        
        byte[] command = addCRC(request);
        output.write(command);
        output.flush();
        
        // Leer eco
        byte[] response = readResponse(8);
        if (!validateCRC(response)) {
            throw new IOException("Write confirmation CRC check failed");
        }
    }
    
    /**
     * Calcular CRC-16 Modbus (polinomio 0xA001)
     */
    private byte[] addCRC(byte[] data) {
        int crc = 0xFFFF;
        for (byte b : data) {
            crc ^= (b & 0xFF);
            for (int i = 0; i < 8; i++) {
                if ((crc & 1) != 0) {
                    crc = (crc >> 1) ^ CRC_POLY;
                } else {
                    crc = crc >> 1;
                }
            }
        }
        
        byte[] result = new byte[data.length + 2];
        System.arraycopy(data, 0, result, 0, data.length);
        result[data.length] = (byte) (crc & 0xFF);
        result[data.length + 1] = (byte) ((crc >> 8) & 0xFF);
        return result;
    }
    
    private boolean validateCRC(byte[] data) {
        if (data.length < 2) return false;
        
        byte[] payload = Arrays.copyOf(data, data.length - 2);
        byte[] calculatedCRC = addCRC(payload);
        
        int len = calculatedCRC.length;
        return data[len - 2] == calculatedCRC[len - 2] &&
               data[len - 1] == calculatedCRC[len - 1];
    }
    
    private byte[] readResponse(int expectedLength) throws IOException {
        ByteBuffer buffer = ByteBuffer.allocate(expectedLength);
        long startTime = System.currentTimeMillis();
        
        while (buffer.position() < expectedLength) {
            if (input.available() > 0) {
                buffer.put((byte) input.read());
            }
            
            if (System.currentTimeMillis() - startTime > TIMEOUT_MS) {
                throw new IOException("Timeout waiting for response");
            }
            
            try {
                Thread.sleep(10);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        
        return buffer.array();
    }
}
```

---

### 1.2 Servicio de Lectura de Inversores

```java
// src/main/java/com/felicity/service/PollingService.java
package com.felicity.service;

import com.felicity.domain.Inverter;
import com.felicity.domain.InverterStatus;
import com.felicity.domain.InverterReading;
import com.felicity.domain.ParameterTemplate;
import com.felicity.repository.InverterRepository;
import com.felicity.repository.InverterStatusRepository;
import com.felicity.repository.InverterReadingRepository;
import com.felicity.protocol.ModbusRTU;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.*;

@Service
public class PollingService {
    
    private static final Logger logger = LoggerFactory.getLogger(PollingService.class);
    
    private final InverterRepository inverterRepository;
    private final InverterStatusRepository statusRepository;
    private final InverterReadingRepository readingRepository;
    private final ConnectionPoolManager connectionPool;
    private final AlertService alertService;
    private final WebSocketService webSocketService;
    
    // Mapeo de parámetros Felicity a registros Modbus (formato decimal)
    private static final Map<String, Integer> PARAMETER_REGISTERS = Map.ofEntries(
        Map.entry("voltage_battery", 4361),      // 0x1109
        Map.entry("current_battery", 4362),      // 0x110A
        Map.entry("soc_battery", 4385),          // 0x1121
        Map.entry("voltage_pv", 4390),           // 0x1126
        Map.entry("power_pv", 4394),             // 0x112A
        Map.entry("voltage_ac", 4369),           // 0x1111
        Map.entry("current_ac", 4370),           // 0x1112
        Map.entry("power_output", 4383),         // 0x111E
        Map.entry("temperature", 4391),          // 0x1127
        Map.entry("frequency", 4395),            // 0x112B
        Map.entry("working_mode", 4361)          // 0x1101
    );
    
    // Mapeo de escalas (multiplicador)
    private static final Map<String, Double> PARAMETER_SCALES = Map.ofEntries(
        Map.entry("voltage_battery", 0.01),
        Map.entry("current_battery", 0.1),
        Map.entry("soc_battery", 1.0),
        Map.entry("voltage_pv", 0.1),
        Map.entry("power_pv", 1.0),
        Map.entry("voltage_ac", 0.1),
        Map.entry("current_ac", 0.1),
        Map.entry("power_output", 1.0),
        Map.entry("temperature", 1.0),
        Map.entry("frequency", 0.01)
    );
    
    private final ScheduledExecutorService executor = Executors.newScheduledThreadPool(10);
    
    public PollingService(
            InverterRepository inverterRepository,
            InverterStatusRepository statusRepository,
            InverterReadingRepository readingRepository,
            ConnectionPoolManager connectionPool,
            AlertService alertService,
            WebSocketService webSocketService) {
        this.inverterRepository = inverterRepository;
        this.statusRepository = statusRepository;
        this.readingRepository = readingRepository;
        this.connectionPool = connectionPool;
        this.alertService = alertService;
        this.webSocketService = webSocketService;
    }
    
    /**
     * Iniciar polling de todos los inversores activos
     * Se ejecuta al iniciar la aplicación
     */
    public void startPolling() {
        List<Inverter> inverters = inverterRepository.findByIsActiveTrue();
        
        for (Inverter inverter : inverters) {
            schedulePolling(inverter);
        }
        
        logger.info("Polling iniciado para {} inversores", inverters.size());
    }
    
    /**
     * Agendar polling periódico para un inversor
     */
    private void schedulePolling(Inverter inverter) {
        long interval = inverter.getPollingInterval() != null ? 
                       inverter.getPollingInterval() : 5;
        
        executor.scheduleAtFixedRate(
            () -> pollInverter(inverter),
            0,
            interval,
            TimeUnit.SECONDS
        );
    }
    
    /**
     * Ejecutar lectura de datos de un inversor
     */
    @Transactional
    protected void pollInverter(Inverter inverter) {
        long startTime = System.currentTimeMillis();
        
        try {
            // Obtener conexión del pool
            ModbusRTU modbus = connectionPool.getConnection(inverter);
            
            // Leer registros
            InverterStatus status = readInverterStatus(modbus, inverter);
            
            // Guardar status
            status.setInverter(inverter);
            status.setLastReadTime(LocalDateTime.now());
            status.setReadingDuration(System.currentTimeMillis() - startTime);
            statusRepository.save(status);
            
            // Marcar como online
            inverter.setLastSeen(LocalDateTime.now());
            inverterRepository.save(inverter);
            
            // Guardar lecturas individuales
            saveReadings(inverter, status);
            
            // Evaluar alertas
            alertService.evaluateAlerts(inverter, status);
            
            // Notificar a WebSocket
            webSocketService.broadcastInverterStatus(inverter.getId(), status);
            
            logger.debug("Polling exitoso para inversor {}", inverter.getInverterId());
            
        } catch (Exception e) {
            logger.error("Error polling inversor {}: {}", 
                        inverter.getInverterId(), e.getMessage());
            
            // Marcar como offline
            inverter.setLastSeen(LocalDateTime.now());
            inverterRepository.save(inverter);
            
            webSocketService.broadcastInverterOffline(inverter.getId());
            
            // Reintentar con backoff
            connectionPool.reconnect(inverter);
        }
    }
    
    /**
     * Leer todos los parámetros de estado del inversor
     */
    private InverterStatus readInverterStatus(ModbusRTU modbus, Inverter inverter) 
            throws Exception {
        
        InverterStatus status = new InverterStatus();
        
        // Leer voltaje de batería (registro 4361)
        int[] regs = modbus.readHoldingRegisters(inverter.getModbusAddress(), 4361, 5);
        status.setBatteryVoltage(regs[0] * 0.01);
        status.setBatteryCurrent(regs[1] * 0.1);
        status.setBatterySOC(regs[4]);
        
        // Leer PV (registro 4390)
        regs = modbus.readHoldingRegisters(inverter.getModbusAddress(), 4390, 4);
        status.setPvVoltage(regs[0] * 0.1);
        status.setPvPower((long)(regs[3]));
        
        // Leer AC (registro 4369)
        regs = modbus.readHoldingRegisters(inverter.getModbusAddress(), 4369, 5);
        status.setAcVoltage(regs[0] * 0.1);
        status.setAcPower((long)(regs[4]));
        
        // Leer temperatura
        regs = modbus.readHoldingRegisters(inverter.getModbusAddress(), 4391, 1);
        status.setTemperature(regs[0]);
        
        // Calcular eficiencia
        if (status.getPvPower() > 0) {
            status.setEfficiency((double) status.getAcPower() / status.getPvPower());
        }
        
        status.setIsOnline(true);
        return status;
    }
    
    /**
     * Guardar lecturas individuales en el histórico
     */
    @Transactional
    private void saveReadings(Inverter inverter, InverterStatus status) {
        List<InverterReading> readings = new ArrayList<>();
        
        readings.add(createReading(inverter, "voltage_battery", 
                    status.getBatteryVoltage(), "V"));
        readings.add(createReading(inverter, "current_battery", 
                    status.getBatteryCurrent(), "A"));
        readings.add(createReading(inverter, "soc_battery", 
                    status.getBatterySOC().doubleValue(), "%"));
        readings.add(createReading(inverter, "power_pv", 
                    status.getPvPower().doubleValue(), "W"));
        readings.add(createReading(inverter, "power_output", 
                    status.getAcPower().doubleValue(), "W"));
        readings.add(createReading(inverter, "efficiency", 
                    status.getEfficiency() * 100, "%"));
        readings.add(createReading(inverter, "temperature", 
                    status.getTemperature().doubleValue(), "°C"));
        
        readingRepository.saveAll(readings);
    }
    
    private InverterReading createReading(Inverter inverter, String parameter, 
                                        Double value, String unit) {
        InverterReading reading = new InverterReading();
        reading.setInverter(inverter);
        reading.setParameter(parameter);
        reading.setValue(value);
        reading.setUnit(unit);
        reading.setTimestamp(LocalDateTime.now());
        reading.setStatus(evaluateReadingStatus(parameter, value));
        return reading;
    }
    
    private ReadingStatus evaluateReadingStatus(String parameter, Double value) {
        // Aquí se pueden agregar lógicas de evaluación
        // Por ahora retornar NORMAL
        return ReadingStatus.NORMAL;
    }
}
```

---

### 1.3 WebSocket Handler

```java
// src/main/java/com/felicity/websocket/InverterWebSocketHandler.java
package com.felicity.websocket;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.CopyOnWriteArrayList;

@Component
public class InverterWebSocketHandler extends TextWebSocketHandler {
    
    private static final Logger logger = LoggerFactory.getLogger(
        InverterWebSocketHandler.class);
    
    private final List<WebSocketSession> sessions = new CopyOnWriteArrayList<>();
    private final ObjectMapper objectMapper = new ObjectMapper();
    
    private final Map<Long, List<WebSocketSession>> inverterSubscriptions = 
        Collections.synchronizedMap(new HashMap<>());
    
    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        sessions.add(session);
        logger.info("WebSocket conectado: {}", session.getId());
    }
    
    @Override
    protected void handleTextMessage(WebSocketSession session, TextMessage message) 
            throws Exception {
        
        try {
            WebSocketMessage msg = objectMapper.readValue(
                message.getPayload(), WebSocketMessage.class);
            
            switch (msg.getType()) {
                case "SUBSCRIBE":
                    handleSubscribe(session, msg.getInverterId());
                    break;
                case "UNSUBSCRIBE":
                    handleUnsubscribe(session, msg.getInverterId());
                    break;
                case "FORCE_READ":
                    handleForceRead(session, msg.getInverterId());
                    break;
                default:
                    logger.warn("Mensaje desconocido: {}", msg.getType());
            }
        } catch (Exception e) {
            logger.error("Error procesando mensaje WebSocket", e);
            sendError(session, "Invalid message format");
        }
    }
    
    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) {
        sessions.remove(session);
        inverterSubscriptions.values().forEach(list -> list.remove(session));
        logger.info("WebSocket desconectado: {}", session.getId());
    }
    
    private void handleSubscribe(WebSocketSession session, Long inverterId) {
        inverterSubscriptions.computeIfAbsent(inverterId, k -> new CopyOnWriteArrayList<>())
            .add(session);
        logger.info("Cliente {} suscrito a inversor {}", session.getId(), inverterId);
    }
    
    private void handleUnsubscribe(WebSocketSession session, Long inverterId) {
        inverterSubscriptions.getOrDefault(inverterId, new CopyOnWriteArrayList<>())
            .remove(session);
    }
    
    private void handleForceRead(WebSocketSession session, Long inverterId) {
        sendMessage(session, new WebSocketMessage(
            "FORCE_READ_ACK",
            inverterId,
            null
        ));
    }
    
    public void broadcastInverterStatus(Long inverterId, Object statusData) {
        WebSocketMessage msg = new WebSocketMessage(
            "INVERTER_STATUS_UPDATE",
            inverterId,
            statusData
        );
        
        List<WebSocketSession> subs = inverterSubscriptions.get(inverterId);
        if (subs != null) {
            subs.forEach(session -> sendMessage(session, msg));
        }
    }
    
    public void broadcastInverterOffline(Long inverterId) {
        WebSocketMessage msg = new WebSocketMessage(
            "INVERTER_OFFLINE",
            inverterId,
            null
        );
        
        List<WebSocketSession> subs = inverterSubscriptions.get(inverterId);
        if (subs != null) {
            subs.forEach(session -> sendMessage(session, msg));
        }
    }
    
    private void sendMessage(WebSocketSession session, WebSocketMessage message) {
        try {
            if (session.isOpen()) {
                session.sendMessage(new TextMessage(
                    objectMapper.writeValueAsString(message)
                ));
            }
        } catch (IOException e) {
            logger.error("Error enviando WebSocket message", e);
        }
    }
    
    private void sendError(WebSocketSession session, String error) {
        try {
            if (session.isOpen()) {
                session.sendMessage(new TextMessage(
                    objectMapper.writeValueAsString(Map.of("error", error))
                ));
            }
        } catch (IOException e) {
            logger.error("Error enviando error message", e);
        }
    }
    
    public static class WebSocketMessage {
        private String type;
        private Long inverterId;
        private Object data;
        
        public WebSocketMessage() {}
        
        public WebSocketMessage(String type, Long inverterId, Object data) {
            this.type = type;
            this.inverterId = inverterId;
            this.data = data;
        }
        
        // Getters and setters
        public String getType() { return type; }
        public void setType(String type) { this.type = type; }
        public Long getInverterId() { return inverterId; }
        public void setInverterId(Long inverterId) { this.inverterId = inverterId; }
        public Object getData() { return data; }
        public void setData(Object data) { this.data = data; }
    }
}
```

---

### 1.4 Servicio de Configuración Dinámica

```java
// src/main/java/com/felicity/service/ParameterConfigService.java
package com.felicity.service;

import com.felicity.domain.InverterParameterConfig;
import com.felicity.domain.ParameterTemplate;
import com.felicity.domain.TemplateParameter;
import com.felicity.repository.InverterParameterConfigRepository;
import com.felicity.repository.ParameterTemplateRepository;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ParameterConfigService {
    
    private final InverterParameterConfigRepository paramConfigRepo;
    private final ParameterTemplateRepository templateRepo;
    private final RedisTemplate<String, Object> redisTemplate;
    private final AuditService auditService;
    private final WebSocketService webSocketService;
    
    public ParameterConfigService(
            InverterParameterConfigRepository paramConfigRepo,
            ParameterTemplateRepository templateRepo,
            RedisTemplate<String, Object> redisTemplate,
            AuditService auditService,
            WebSocketService webSocketService) {
        this.paramConfigRepo = paramConfigRepo;
        this.templateRepo = templateRepo;
        this.redisTemplate = redisTemplate;
        this.auditService = auditService;
        this.webSocketService = webSocketService;
    }
    
    /**
     * Obtener configuración en caché
     */
    @Cacheable(value = "inverter-config", key = "#inverterId")
    public Map<String, InverterParameterConfig> getInverterConfig(Long inverterId) {
        List<InverterParameterConfig> configs = 
            paramConfigRepo.findByInverterId(inverterId);
        
        Map<String, InverterParameterConfig> configMap = new HashMap<>();
        for (InverterParameterConfig config : configs) {
            configMap.put(config.getParameterName(), config);
        }
        
        return configMap;
    }
    
    /**
     * Actualizar configuración de parámetro
     */
    @Transactional
    @CachePut(value = "inverter-config", key = "#inverterId")
    public Map<String, InverterParameterConfig> updateParameterConfig(
            Long inverterId,
            String parameterName,
            InverterParameterConfig newConfig,
            Long userId) {
        
        // Obtener config anterior para auditoría
        InverterParameterConfig oldConfig = paramConfigRepo
            .findByInverterIdAndParameterName(inverterId, parameterName)
            .orElse(null);
        
        // Actualizar
        newConfig.setParameterName(parameterName);
        newConfig.setLastModified(LocalDateTime.now());
        paramConfigRepo.save(newConfig);
        
        // Registrar cambio en auditoría
        auditService.logChange(
            "InverterParameterConfig",
            inverterId,
            oldConfig,
            newConfig,
            userId
        );
        
        // Notificar a clientes
        webSocketService.broadcastConfigUpdate(inverterId);
        
        // Retornar configuración actualizada
        return getInverterConfig(inverterId);
    }
    
    /**
     * Aplicar plantilla a un inversor
     */
    @Transactional
    public void applyTemplateToInverter(Long inverterId, Long templateId) {
        ParameterTemplate template = templateRepo.findById(templateId)
            .orElseThrow(() -> new IllegalArgumentException("Template not found"));
        
        List<TemplateParameter> templateParams = template.getTemplateParameters();
        
        for (TemplateParameter tp : templateParams) {
            if (tp.isEnabledByDefault()) {
                InverterParameterConfig config = new InverterParameterConfig();
                config.setParameterName(tp.getParameterName());
                config.setIsEnabled(true);
                paramConfigRepo.save(config);
            }
        }
    }
    
    /**
     * Obtener parámetro específico
     */
    public InverterParameterConfig getParameter(Long inverterId, String paramName) {
        return paramConfigRepo.findByInverterIdAndParameterName(inverterId, paramName)
            .orElseThrow(() -> new IllegalArgumentException("Parameter not found"));
    }
    
    /**
     * Habilitar/deshabilitar parámetro
     */
    @Transactional
    public void toggleParameter(Long inverterId, String paramName, boolean enabled) {
        InverterParameterConfig config = getParameter(inverterId, paramName);
        config.setIsEnabled(enabled);
        paramConfigRepo.save(config);
        
        webSocketService.broadcastConfigUpdate(inverterId);
    }
    
    /**
     * Actualizar umbrales
     */
    @Transactional
    public void updateThresholds(Long inverterId, String paramName, 
                                Double warning, Double alarm) {
        InverterParameterConfig config = getParameter(inverterId, paramName);
        config.setWarningThreshold(warning);
        config.setAlarmThreshold(alarm);
        paramConfigRepo.save(config);
        
        webSocketService.broadcastConfigUpdate(inverterId);
    }
}
```

---

## PARTE 2: FRONTEND REACT

### 2.1 Hook de WebSocket

```typescript
// src/hooks/useWebSocket.ts
import { useEffect, useState, useCallback } from 'react';
import { useInverterStore } from '../store/inverterStore';

interface WebSocketMessage {
  type: string;
  inverterId: number;
  timestamp?: string;
  data?: any;
}

export function useWebSocket() {
  const [connected, setConnected] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const updateInverterStatus = useInverterStore(s => s.updateInverterStatus);
  const addAlert = useInverterStore(s => s.addAlert);
  
  const connect = useCallback(() => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const ws = new WebSocket(`${protocol}//${window.location.host}/ws/inverters`);
    
    ws.onopen = () => {
      setConnected(true);
      setError(null);
      console.log('WebSocket conectado');
    };
    
    ws.onmessage = (event) => {
      try {
        const message: WebSocketMessage = JSON.parse(event.data);
        
        switch (message.type) {
          case 'INVERTER_STATUS_UPDATE':
            updateInverterStatus(message.inverterId, message.data);
            break;
          case 'INVERTER_OFFLINE':
            updateInverterStatus(message.inverterId, { isOnline: false });
            break;
          case 'ALERT_TRIGGERED':
            addAlert(message.data);
            break;
          case 'CONFIG_UPDATED':
            // Recargar configuración
            window.location.reload();
            break;
        }
      } catch (e) {
        console.error('Error parsing WebSocket message', e);
      }
    };
    
    ws.onerror = () => {
      setError('WebSocket error');
      setConnected(false);
    };
    
    ws.onclose = () => {
      setConnected(false);
      // Reconectar después de 3 segundos
      setTimeout(connect, 3000);
    };
    
    return ws;
  }, []);
  
  useEffect(() => {
    const ws = connect();
    return () => ws.close();
  }, []);
  
  return { connected, error };
}
```

---

### 2.2 Store Zustand

```typescript
// src/store/inverterStore.ts
import create from 'zustand';
import { InverterStatus, Alert } from '../types';

interface InverterStore {
  inverters: any[];
  statusMap: Map<number, InverterStatus>;
  alerts: Alert[];
  chartData: Map<number, any[]>;
  
  updateInverterStatus: (inverterId: number, status: Partial<InverterStatus>) => void;
  addAlert: (alert: Alert) => void;
  addChartPoint: (inverterId: number, point: any) => void;
  setInverters: (inverters: any[]) => void;
}

export const useInverterStore = create<InverterStore>((set) => ({
  inverters: [],
  statusMap: new Map(),
  alerts: [],
  chartData: new Map(),
  
  updateInverterStatus: (inverterId, status) => set((state) => {
    const newStatusMap = new Map(state.statusMap);
    newStatusMap.set(inverterId, {
      ...newStatusMap.get(inverterId),
      ...status
    });
    return { statusMap: newStatusMap };
  }),
  
  addAlert: (alert) => set((state) => ({
    alerts: [alert, ...state.alerts].slice(0, 100) // Últimas 100
  })),
  
  addChartPoint: (inverterId, point) => set((state) => {
    const data = state.chartData.get(inverterId) || [];
    const newData = [...data, point].slice(-288); // Últimas 24h (5s * 288)
    
    const newChartData = new Map(state.chartData);
    newChartData.set(inverterId, newData);
    return { chartData: newChartData };
  }),
  
  setInverters: (inverters) => set({ inverters })
}));
```

---

### 2.3 Componente Dashboard

```typescript
// src/components/Dashboard/Dashboard.tsx
import React, { useEffect, useState } from 'react';
import { useInverterStore } from '../../store/inverterStore';
import { useWebSocket } from '../../hooks/useWebSocket';
import InverterCard from './InverterCard';
import AlertPanel from '../Alerts/AlertPanel';
import './Dashboard.css';

export function Dashboard() {
  const inverters = useInverterStore(s => s.inverters);
  const alerts = useInverterStore(s => s.alerts);
  const { connected } = useWebSocket();
  const [filter, setFilter] = useState('all');
  
  useEffect(() => {
    // Cargar inversores iniciales
    fetch('/api/inverters')
      .then(r => r.json())
      .then(data => useInverterStore.setState({ inverters: data }));
  }, []);
  
  const filtered = inverters.filter(inv => {
    if (filter === 'online') return useInverterStore.getState()
      .statusMap.get(inv.id)?.isOnline;
    if (filter === 'offline') return !useInverterStore.getState()
      .statusMap.get(inv.id)?.isOnline;
    return true;
  });
  
  return (
    <div className="dashboard">
      <header className="dashboard-header">
        <h1>Panel de Control - Felicity Solar Monitor</h1>
        <div className="status-indicator">
          <span className={`indicator ${connected ? 'connected' : 'disconnected'}`}></span>
          {connected ? 'En vivo' : 'Reconectando...'}
        </div>
      </header>
      
      <div className="dashboard-content">
        <aside className="alert-sidebar">
          <AlertPanel alerts={alerts.slice(0, 10)} />
        </aside>
        
        <main className="inverters-main">
          <div className="toolbar">
            <h2>Inversores ({filtered.length})</h2>
            <div className="filters">
              <button 
                className={filter === 'all' ? 'active' : ''}
                onClick={() => setFilter('all')}
              >
                Todos
              </button>
              <button 
                className={filter === 'online' ? 'active' : ''}
                onClick={() => setFilter('online')}
              >
                Online
              </button>
              <button 
                className={filter === 'offline' ? 'active' : ''}
                onClick={() => setFilter('offline')}
              >
                Offline
              </button>
            </div>
          </div>
          
          <div className="inverters-grid">
            {filtered.length > 0 ? (
              filtered.map(inverter => (
                <InverterCard key={inverter.id} inverter={inverter} />
              ))
            ) : (
              <p className="empty-state">No hay inversores</p>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
```

---

### 2.4 Gráfico en Vivo

```typescript
// src/components/Dashboard/RealTimeChart.tsx
import React, { useEffect } from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer
} from 'recharts';
import { useInverterStore } from '../../store/inverterStore';

interface RealTimeChartProps {
  inverterId: number;
  parameter: string;
}

export function RealTimeChart({ inverterId, parameter }: RealTimeChartProps) {
  const chartData = useInverterStore(s => s.chartData.get(inverterId)) || [];
  
  return (
    <div className="chart-container">
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={chartData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis 
            dataKey="time"
            tick={{ fontSize: 12 }}
          />
          <YAxis 
            label={{ value: 'Potencia (W)', angle: -90, position: 'insideLeft' }}
          />
          <Tooltip 
            formatter={(value) => value.toFixed(2)}
            labelFormatter={(label) => `${label}`}
          />
          <Line
            type="monotone"
            dataKey={parameter}
            stroke="#8884d8"
            dot={false}
            isAnimationActive={false}
            strokeWidth={2}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
```

---

## PARTE 3: APP FLUTTER

### 3.1 Pantalla de Login

```dart
// lib/screens/login_screen.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  bool _isLoading = false;
  String? _error;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  void _login() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final authProvider = Provider.of<AuthProvider>(context, listen: false);
      await authProvider.login(
        _emailController.text,
        _passwordController.text,
      );

      if (mounted && authProvider.isAuthenticated) {
        Navigator.of(context).pushReplacementNamed('/dashboard');
      }
    } catch (e) {
      setState(() {
        _error = 'Error de login: $e';
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Image.asset('assets/logo.png', width: 120, height: 120),
              const SizedBox(height: 32),
              
              Text(
                'Felicity Solar Monitor',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 8),
              
              Text(
                'Sistema de Monitoreo de Inversores',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodySmall,
              ),
              const SizedBox(height: 48),
              
              TextField(
                controller: _emailController,
                decoration: InputDecoration(
                  labelText: 'Correo Electrónico',
                  prefixIcon: const Icon(Icons.email),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                keyboardType: TextInputType.emailAddress,
                enabled: !_isLoading,
              ),
              const SizedBox(height: 16),
              
              TextField(
                controller: _passwordController,
                decoration: InputDecoration(
                  labelText: 'Contraseña',
                  prefixIcon: const Icon(Icons.lock),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                obscureText: true,
                enabled: !_isLoading,
              ),
              const SizedBox(height: 8),
              
              if (_error != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 16.0),
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.red[100],
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      _error!,
                      style: TextStyle(color: Colors.red[800]),
                    ),
                  ),
                ),
              
              SizedBox(
                height: 48,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _login,
                  child: _isLoading
                      ? const SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Text('Ingresar'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
```

---

### 3.2 Provider de Inversores

```dart
// lib/providers/inverter_provider.dart
import 'package:flutter/material.dart';
import '../models/inverter_model.dart';
import '../models/inverter_status.dart';
import '../services/api_service.dart';
import '../services/websocket_service.dart';

class InverterProvider extends ChangeNotifier {
  final ApiService apiService;
  final WebSocketService webSocketService;
  
  List<InverterModel> _inverters = [];
  Map<int, InverterStatus> _statusMap = {};
  bool _isLoading = false;
  String? _error;

  InverterProvider({
    required this.apiService,
    required this.webSocketService,
  }) {
    _setupWebSocket();
  }

  List<InverterModel> get inverters => _inverters;
  Map<int, InverterStatus> get statusMap => _statusMap;
  bool get isLoading => _isLoading;
  String? get error => _error;

  InverterStatus? getInverterStatus(int inverterId) => _statusMap[inverterId];

  Future<void> fetchInverters() async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      _inverters = await apiService.getInverters();
      notifyListeners();
    } catch (e) {
      _error = 'Error al cargar inversores: $e';
      notifyListeners();
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  void _setupWebSocket() {
    webSocketService.onStatusUpdate = (inverterId, status) {
      _statusMap[inverterId] = status;
      notifyListeners();
    };

    webSocketService.onInverterOffline = (inverterId) {
      if (_statusMap.containsKey(inverterId)) {
        _statusMap[inverterId]?.isOnline = false;
        notifyListeners();
      }
    };
  }

  InverterModel? getInverterById(int id) {
    try {
      return _inverters.firstWhere((inv) => inv.id == id);
    } catch (e) {
      return null;
    }
  }
}
```

---

### 3.3 WebSocket Service

```dart
// lib/services/websocket_service.dart
import 'package:web_socket_channel/web_socket_channel.dart';
import 'dart:convert';
import '../models/inverter_status.dart';

typedef StatusUpdateCallback = void Function(int inverterId, InverterStatus status);
typedef OfflineCallback = void Function(int inverterId);

class WebSocketService {
  late WebSocketChannel _channel;
  String _baseUrl;
  
  StatusUpdateCallback? onStatusUpdate;
  OfflineCallback? onInverterOffline;

  WebSocketService({required String baseUrl}) : _baseUrl = baseUrl;

  void connect() {
    final protocol = _baseUrl.startsWith('https') ? 'wss' : 'ws';
    final host = _baseUrl.replaceAll('http://', '').replaceAll('https://', '');
    final url = '$protocol://$host/ws/inverters';

    try {
      _channel = WebSocketChannel.connect(Uri.parse(url));
      _listenToMessages();
    } catch (e) {
      print('WebSocket connection error: $e');
      Future.delayed(Duration(seconds: 3), () => connect());
    }
  }

  void _listenToMessages() {
    _channel.stream.listen(
      (message) {
        try {
          final data = jsonDecode(message);
          final type = data['type'] as String?;

          switch (type) {
            case 'INVERTER_STATUS_UPDATE':
              _handleStatusUpdate(data);
              break;
            case 'INVERTER_OFFLINE':
              _handleInverterOffline(data);
              break;
            case 'ALERT_TRIGGERED':
              _handleAlert(data);
              break;
          }
        } catch (e) {
          print('Error processing WebSocket message: $e');
        }
      },
      onError: (error) {
        print('WebSocket error: $error');
        disconnect();
        Future.delayed(Duration(seconds: 3), () => connect());
      },
      onDone: () {
        print('WebSocket closed');
        Future.delayed(Duration(seconds: 3), () => connect());
      },
    );
  }

  void _handleStatusUpdate(Map<String, dynamic> data) {
    final inverterId = data['inverterId'] as int;
    final statusData = data['data'] as Map<String, dynamic>;
    
    final status = InverterStatus.fromJson(statusData);
    onStatusUpdate?.call(inverterId, status);
  }

  void _handleInverterOffline(Map<String, dynamic> data) {
    final inverterId = data['inverterId'] as int;
    onInverterOffline?.call(inverterId);
  }

  void _handleAlert(Map<String, dynamic> data) {
    // Manejar alertas
  }

  void subscribe(int inverterId) {
    _sendMessage({
      'type': 'SUBSCRIBE',
      'inverterId': inverterId,
    });
  }

  void unsubscribe(int inverterId) {
    _sendMessage({
      'type': 'UNSUBSCRIBE',
      'inverterId': inverterId,
    });
  }

  void forceRead(int inverterId) {
    _sendMessage({
      'type': 'FORCE_READ',
      'inverterId': inverterId,
    });
  }

  void _sendMessage(Map<String, dynamic> message) {
    try {
      if (!_channel.sink.sink.isClosed) {
        _channel.sink.add(jsonEncode(message));
      }
    } catch (e) {
      print('Error sending WebSocket message: $e');
    }
  }

  void disconnect() {
    try {
      _channel.sink.close();
    } catch (e) {
      print('Error closing WebSocket: $e');
    }
  }
}
```

---

## INSTRUCCIONES DE DEPLOYMENT

### Backend (Spring Boot)

```bash
# 1. Clonar y configurar
git clone <repo-url>
cd felicity-backend
cp .env.example .env
# Editar .env con credenciales PostgreSQL

# 2. Generar desde JDL
jhipster jdl felicity.jdl

# 3. Compilar
./gradlew build

# 4. Ejecutar
./gradlew bootRun

# Acceder a http://localhost:8080
```

### Frontend (React)

```bash
cd felicity-frontend
npm install
npm run dev

# Build para producción
npm run build
npm run preview
```

### Flutter

```bash
cd felicity_app
flutter pub get
flutter run -d <device-id>

# Build APK
flutter build apk --release

# Build iOS
flutter build ios --release
```

---

Este documento proporciona ejemplos concretos y listos para adaptar a tu proyecto específico.
