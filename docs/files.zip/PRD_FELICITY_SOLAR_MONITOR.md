# PRD: Sistema Integrado de Monitoreo Felicity - 200 Inversores
## Aplicación Multi-Plataforma (Web React + App Flutter)

**Versión:** 1.0  
**Fecha:** Mayo 2024  
**Autores:** Solar Energy Systems  
**Audiencia:** Desarrollo, Stakeholders, Product Team

---

## 📋 TABLA DE CONTENIDOS

1. [Resumen Ejecutivo](#resumen-ejecutivo)
2. [Visión y Alcance](#visión-y-alcance)
3. [Requisitos Funcionales](#requisitos-funcionales)
4. [Análisis Técnico de Inversores Solares](#análisis-técnico-de-inversores-solares)
5. [Configurabilidad Dinámica de Parámetros](#configurabilidad-dinámica-de-parámetros)
6. [Arquitectura del Sistema](#arquitectura-del-sistema)
7. [Especificación de Base de Datos (JDL)](#especificación-de-base-de-datos)
8. [API REST + WebSocket](#api-rest--websocket)
9. [Frontend React](#frontend-react)
10. [App Flutter](#app-flutter)
11. [Reportes y Análisis](#reportes-y-análisis)
12. [Roadmap de Implementación](#roadmap-de-implementación)
13. [KPIs y Métricas](#kpis-y-métricas)

---

## 📊 RESUMEN EJECUTIVO

### Objetivo Principal
Crear una plataforma **centralizada, escalable y configurable** para monitorear hasta **200 inversores solares Felicity** en tiempo real, con capacidad de:
- Configuración dinámica de parámetros por inversor
- Visualización en vivo vía WebSocket
- Reportes de eficiencia y degradación
- Acceso desde web (React) y móvil (Flutter)
- Almacenamiento histórico para análisis predictivo

### Valor Comercial
- **Visibilidad en tiempo real** del rendimiento del sistema solar
- **Detección proactiva** de fallas (bajo rendimiento, desconexiones)
- **Optimización de operaciones** mediante reportes de eficiencia
- **Escalabilidad** para plantas solares de gran tamaño
- **Accesibilidad** desde web y móvil para gestión remota

---

## 🎯 VISIÓN Y ALCANCE

### Visión
*Una plataforma unificada que permite a operadores de plantas solares monitorear, configurar y analizar el rendimiento de cientos de inversores con una interfaz intuitiva y en tiempo real.*

### Alcance - Fase 1 (MVP)

#### ✅ INCLUIDO
- Monitoreo de **hasta 200 inversores Felicity**
- Protocolo **Modbus RTU** para comunicación
- **WebSocket** para datos en tiempo real
- **Dashboard React** con métricas en vivo
- **Aplicación Flutter** para consulta móvil
- **Configurabilidad dinámica** de parámetros por inversor
- Histórico de datos (últimos 12 meses)
- Reportes de eficiencia básicos (diarios, semanales, mensuales)
- Sistema de alertas por umbral

#### ❌ NO INCLUIDO (Fase 2+)
- Integración con API de pronóstico meteorológico
- Machine Learning para predicción de fallas
- Control remoto de parámetros (solo lectura y configuración estática)
- Integración con sistemas de pagos
- Multi-tenencia (un cliente por despliegue)

---

## 📌 REQUISITOS FUNCIONALES

### RF-001: Gestión de Inversores
**Descripción:** El sistema debe permitir registrar, actualizar y eliminar inversores.

- RF-001.1: Crear inversor con datos básicos (ID, marca, modelo, ubicación, dirección Modbus)
- RF-001.2: Actualizar información del inversor
- RF-001.3: Listar todos los inversores con filtros (ubicación, estado, marca)
- RF-001.4: Ver detalles de un inversor específico
- RF-001.5: Eliminar inversor (soft delete)
- RF-001.6: Bulk import de inversores (CSV)

**Criterio de Aceptación:**
```gherkin
Scenario: Crear un nuevo inversor Felicity
  Given El usuario tiene permisos de administración
  When Completa el formulario con ID 001, ubicación "Techo", dirección Modbus 0x01
  Then El inversor se registra en la BD
  And Se inicia polling automático
  And Aparece en el dashboard
```

---

### RF-002: Configurabilidad Dinámica de Parámetros
**Descripción:** Cada inversor puede tener un **perfil único de parámetros** a monitorear.

- RF-002.1: Definir plantilla de parámetros (por modelo/marca)
- RF-002.2: Asignar parámetros a un inversor
- RF-002.3: Modificar parámetros sin reiniciar la app
- RF-002.4: Validar rangos de valores permitidos
- RF-002.5: Historial de cambios de configuración

**Ejemplo de Configuración:**

```json
{
  "inverterId": "INV-001",
  "parameters": [
    {
      "id": "voltage_battery",
      "name": "Voltaje de Batería",
      "register": "0x1108",
      "type": "FLOAT",
      "unit": "V",
      "scale": 0.01,
      "enabled": true,
      "warningThreshold": 45,
      "alarmThreshold": 40
    },
    {
      "id": "current_battery",
      "name": "Corriente de Batería",
      "register": "0x1109",
      "type": "SIGNED_INT",
      "unit": "A",
      "scale": 0.1,
      "enabled": true,
      "warningThreshold": 120,
      "alarmThreshold": 150
    },
    {
      "id": "power_pv",
      "name": "Potencia PV",
      "register": "0x112A",
      "type": "INT",
      "unit": "W",
      "scale": 1,
      "enabled": true,
      "warningThreshold": null,
      "alarmThreshold": null
    }
  ]
}
```

---

### RF-003: Monitoreo en Tiempo Real
**Descripción:** WebSocket para streaming de datos sin latencia.

- RF-003.1: Conexión WebSocket para cada sesión de usuario
- RF-003.2: Actualización de métricas cada 1 segundo (configurable)
- RF-003.3: Manejo de desconexiones con reconexión automática
- RF-003.4: Compresión de datos para óptima transferencia
- RF-003.5: Soporte para múltiples usuarios simultáneos

**Evento WebSocket Ejemplo:**

```javascript
{
  "type": "INVERTER_DATA_UPDATE",
  "inverterId": "INV-001",
  "timestamp": "2024-05-10T14:32:45.123Z",
  "metrics": {
    "voltage_battery": { "value": 48.2, "unit": "V", "trend": "↑" },
    "current_battery": { "value": 45.3, "unit": "A", "trend": "↓" },
    "power_pv": { "value": 3500, "unit": "W", "trend": "→" },
    "efficiency": { "value": 0.94, "unit": "%", "status": "NORMAL" },
    "status": "CHARGING_BATTERY",
    "temperature": { "value": 38, "unit": "°C" }
  }
}
```

---

### RF-004: Dashboard Web (React)
**Descripción:** Interfaz web para visualización y control.

- RF-004.1: Vista general de todos los inversores (grid o tabla)
- RF-004.2: Indicadores de estado (Online/Offline/Alerta)
- RF-004.3: Gráficos en vivo de voltaje, corriente, potencia
- RF-004.4: Detalles del inversor con histórico
- RF-004.5: Panel de configuración de parámetros
- RF-004.6: Mapa de ubicaciones de inversores (opcional)
- RF-004.7: Notificaciones y alertas en tiempo real

---

### RF-005: Aplicación Flutter
**Descripción:** App móvil para monitoreo en cualquier lugar.

- RF-005.1: Login con credenciales
- RF-005.2: Dashboard móvil optimizado
- RF-005.3: Vista de inversor individual con gráficos
- RF-005.4: Notificaciones push en caso de alerta
- RF-005.5: Descarga de reportes en PDF
- RF-005.6: Modo offline con caché local

---

### RF-006: Reportes y Análisis
**Descripción:** Generación de reportes de eficiencia y degradación.

- RF-006.1: Reporte diario de producción por inversor
- RF-006.2: Reporte semanal con análisis comparativo
- RF-006.3: Reporte mensual con KPIs de eficiencia
- RF-006.4: Detección de degradación (% por mes)
- RF-006.5: Análisis de disponibilidad (uptime)
- RF-006.6: Exportar a PDF, Excel, CSV

**Métricas de Reporte:**
- Energy Generated (kWh)
- Peak Efficiency (%)
- Average Operating Hours
- Temperature Impact Analysis
- Downtime Events
- Forecast vs Actual (si aplica)

---

### RF-007: Alertas y Notificaciones
**Descripción:** Sistema de alertas con múltiples canales.

- RF-007.1: Alertas por umbral (warning y alarm)
- RF-007.2: Alertas de desconexión
- RF-007.3: Alertas de cambio de estado
- RF-007.4: Notificación en tiempo real (in-app + email)
- RF-007.5: Configuración de umbrales por usuario
- RF-007.6: Historial de alertas con resolución

---

## 🔌 ANÁLISIS TÉCNICO DE INVERSORES SOLARES

### Contexto: Inversores Felicity

**Marca:** Felicity (Inversores hibridados de 3-5kW)  
**Protocolo:** Modbus RTU (basado en guía técnica)  
**Aplicación:** Sistemas solares fotovoltaicos con almacenamiento en batería

### Principios de Funcionamiento

#### 1. **Flujos de Energía**

Un inversor solar híbrido gestiona tres fuentes:

```
        ┌─── PV Array (Paneles) ───┐
        │                           │
    ────┼──────► INVERSOR ◄────────┼──── Batería
        │          (Felicity)       │
        └─────────────────────────┘
              │
              ▼
         AC Output (Casa/Red)
```

**Modos de Operación:**

| Modo | Descripción | Prioridades |
|------|-------------|-------------|
| **PV-Charging** | Paneles cargan batería | PV > Red |
| **PV-Supply** | Paneles alimentan carga | PV > Batería |
| **Battery-Supply** | Batería alimenta carga | Batería > Red |
| **Grid-Charging** | Red carga batería | Red > PV |
| **Grid-Supply** | Red alimenta carga | Red > Batería |
| **Idle/Standby** | Sistema en reposo | - |

---

#### 2. **Parámetros Críticos a Monitorear**

##### **Batería**
```
┌─────────────────────────────────────┐
│ BATERÍA                             │
├─────────────────────────────────────┤
│ Voltaje (V)         | 24, 48, 96V  │  ← CRÍTICO
│ Corriente (A)       | ±200A máx    │  ← CRÍTICO
│ SOC (%)             | 0-100%       │  ← ESTADO
│ Temperatura (°C)    | -20 a +60    │  ← SEGURIDAD
│ Estado de Salud     | Cycles       │  ← PREDICTIVO
└─────────────────────────────────────┘
```

**Interpretación:**
- **Voltaje bajo** → Batería descargada, riesgo de apagón
- **Voltaje alto** → Sobrecarga, riesgo de daño
- **Corriente alta** → Alta demanda o cortocircuito
- **Temperatura > 50°C** → Degradación acelerada

---

##### **PV (Paneles Solares)**
```
┌─────────────────────────────────────┐
│ PANELES SOLARES                     │
├─────────────────────────────────────┤
│ Voltaje PV (V)      | 0-600V       │
│ Potencia PV (W)     | 0-5000W      │  ← RENDIMIENTO
│ Radiación (W/m²)    | 0-1000       │  ← IDEAL 1000
│ Temperatura Panel   | -10 a +80°C  │  ← AFECTA EFICIENCIA
└─────────────────────────────────────┘
```

**Cálculos de Eficiencia:**

```
Eficiencia Teórica = (Potencia PV / Radiación × Área) × 100
Eficiencia Real    = (Potencia Salida / Potencia PV) × 100
Degradación Anual  = (Eficiencia Mes 1 - Eficiencia Mes 12) / 12
```

---

##### **AC (Salida)**
```
┌─────────────────────────────────────┐
│ SALIDA AC                           │
├─────────────────────────────────────┤
│ Voltaje AC (V)      | 110-250V     │  ← REGULACIÓN
│ Frecuencia (Hz)     | 50/60Hz      │  ← CRÍTICO
│ Potencia (W)        | Real-time    │
│ Factor de Potencia  | 0-1          │  ← CALIDAD
│ THD (%)             | <5% ideal    │  ← ARMÓNICOS
└─────────────────────────────────────┘
```

---

##### **Red (Grid)**
```
┌─────────────────────────────────────┐
│ RED ELÉCTRICA                       │
├─────────────────────────────────────┤
│ Voltaje Red (V)     | ±10% nominal │
│ Frecuencia (Hz)     | ±0.2Hz       │
│ Potencia Disponible | Dinámico     │
└─────────────────────────────────────┘
```

---

#### 3. **Registros Modbus RTU (Dirección Decimal)**

| Dirección | Parámetro | Tipo | Escala | Rango | Nota |
|-----------|-----------|------|--------|-------|------|
| **4361** | Voltaje Batería | U16 | 0.01 | 0-100V | /100 en doc |
| **4362** | Corriente Batería | I16 | 0.1 | -200 a +200A | signed |
| **4371** | Voltaje AC | U16 | 0.1 | 0-300V | /10 |
| **4374** | Voltaje Red | U16 | 0.1 | 0-300V | /10 |
| **4383** | Potencia Carga | U16 | 1 | 0-5000W | raw |
| **4385** | SOC Batería | U16 | 1 | 0-100% | raw |
| **4390** | Voltaje PV | U16 | 0.1 | 0-600V | /10 |
| **4394** | Potencia PV | I16 | 1 | -5000 a +5000W | signed |
| **4385** | Temperatura | I16 | 1 | -50 a +100°C | signed |

*Nota: Estos registros pueden variar según versión firmware. Validar con manual técnico.*

---

#### 4. **Estados y Transiciones**

```
            ┌─────────────┐
            │   STARTUP   │
            └──────┬──────┘
                   │
           ┌───────▼────────┐
           │  Self-Check OK?│
           └─┬──────────┬───┘
           NO│          │YES
             │          ▼
             │     ┌─────────────┐
             │     │   READY     │
             │     └──┬──┬──┬──┬─┘
             │        │  │  │  └──► Battery Supply
             │        │  │  └─────► Grid Supply
             │        │  └────────► PV Supply
             │        └───────────► Idle
             │
             ▼
        ┌─────────────┐
        │   FAULT     │
        └─────────────┘
```

---

### 5. **Métricas de Eficiencia**

#### **Eficiencia de Conversión**
```
η_inversor = (Potencia AC Salida / Potencia DC Entrada) × 100
Típica: 92-97% (Felicity: ~94%)
```

#### **Factor de Degradación Anual**
```
Degradación_Anual = ((Energía_Mes1 - Energía_Mes12) / 12) / Energía_Mes1
Típica: 0.5-0.8% anual
Alerta: > 1.5% anual (posible falla)
```

#### **Disponibilidad (Uptime)**
```
Uptime% = (Horas_Operación / Horas_Disponibles) × 100
Objetivo: > 99.5% (horas de sol)
```

---

## ⚙️ CONFIGURABILIDAD DINÁMICA DE PARÁMETROS

### Objetivo
Permitir que cada inversor tenga un **perfil único** de parámetros a monitorear, sin requerir cambio de código.

### Arquitectura

```
┌──────────────────────────────────────┐
│    CONFIGURACIÓN DE INVERSOR         │
├──────────────────────────────────────┤
│                                      │
│  ┌────────────────────────────────┐  │
│  │ 1. TEMPLATE (por modelo)       │  │
│  │    - Felicity 3kW               │  │
│  │    - Felicity 5kW               │  │
│  │    - (Futuro: Axpert, etc)     │  │
│  └────────────────────────────────┘  │
│                                      │
│  ┌────────────────────────────────┐  │
│  │ 2. INVERTER CONFIG             │  │
│  │    (Hereda de template)         │  │
│  │    - ID: INV-001                │  │
│  │    - Parámetros habilitados     │  │
│  │    - Umbrales personalizados    │  │
│  │    - Polling rate               │  │
│  └────────────────────────────────┘  │
│                                      │
│  ┌────────────────────────────────┐  │
│  │ 3. PARAMETER                   │  │
│  │    - Register address           │  │
│  │    - Data type                  │  │
│  │    - Scale factor               │  │
│  │    - Warning/Alarm thresholds   │  │
│  │    - Display format             │  │
│  └────────────────────────────────┘  │
│                                      │
└──────────────────────────────────────┘
```

### Flujo de Aplicación de Configuración

```java
1. Admin edita parámetro en UI
   ↓
2. POST /api/inverters/{id}/parameters/{paramId}
   ↓
3. Backend valida cambio
   ↓
4. Guarda en BD (InverterParameterConfig)
   ↓
5. Service recarga configuración en caché
   ↓
6. Polling service aplica nuevo parámetro
   ↓
7. WebSocket notifica a clientes: "CONFIG_UPDATED"
   ↓
8. Frontend actualiza dashboard
```

### Ejemplos de Configuraciones

#### **Configuración A: Monitoreo Estándar (80% de plantas)**
```json
{
  "name": "Standard Monitor",
  "parameters": [
    "voltage_battery",
    "current_battery",
    "soc",
    "power_pv",
    "power_output",
    "efficiency",
    "temperature"
  ]
}
```

#### **Configuración B: Monitoreo Avanzado (plantas de investigación)**
```json
{
  "name": "Research Monitor",
  "parameters": [
    "voltage_battery",
    "current_battery",
    "voltage_pv",
    "current_pv",
    "power_pv",
    "power_output",
    "efficiency",
    "temperature",
    "frequency_ac",
    "voltage_ac",
    "tota_harmonics_distortion",
    "power_factor"
  ]
}
```

#### **Configuración C: Monitoreo Mínimo (baja potencia)**
```json
{
  "name": "Minimal Monitor",
  "parameters": [
    "voltage_battery",
    "soc",
    "power_output",
    "status"
  ]
}
```

---

## 🏗️ ARQUITECTURA DEL SISTEMA

### Diagrama de Componentes

```
┌─────────────────────────────────────────────────────────────────┐
│                     CAPA DE PRESENTACIÓN                         │
├──────────────────────────┬──────────────────────────────────────┤
│   React Dashboard Web    │      Flutter Mobile App              │
│  - Grid de inversores    │   - Login/Auth                       │
│  - Gráficos en vivo      │   - Dashboard móvil                  │
│  - Panel de control      │   - Notificaciones push              │
│  - Reportes             │   - Cache offline                    │
└──────────────────────────┴──────────────────────────────────────┘
                           │
            ┌──────────────┼──────────────┐
            │              │              │
      ┌─────▼────┐    ┌────▼─────┐  ┌───▼──────┐
      │ WebSocket│    │ REST API  │  │Auth API  │
      │ (datos)  │    │ (config)  │  │(JWT)     │
      └─────┬────┘    └────┬─────┘  └───┬──────┘
            │              │             │
            └──────────────┼─────────────┘
                          │
┌─────────────────────────▼─────────────────────────────────────────┐
│                    CAPA DE LÓGICA (SpringBoot)                     │
├────────────────────────────────────────────────────────────────────┤
│                                                                     │
│ ┌─────────────────────────────────────────────────────────────┐   │
│ │              SERVICIOS CORE                                 │   │
│ │  - InverterService (CRUD)                                   │   │
│ │  - ParameterConfigService (configuración dinámica)          │   │
│ │  - PollingService (lectura periódica)                       │   │
│ │  - AlertService (detección y notificación)                  │   │
│ │  - ReportService (generación de reportes)                   │   │
│ │  - WebSocketHandler (streaming de datos)                    │   │
│ └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
│ ┌─────────────────────────────────────────────────────────────┐   │
│ │         PROTOCOL ADAPTERS                                   │   │
│ │  ┌──────────────┐     ┌──────────────┐                     │   │
│ │  │ Modbus RTU   │     │ PI30 (Future)│                     │   │
│ │  │ - CRC        │     │              │                     │   │
│ │  │ - Registers  │     │              │                     │   │
│ │  │ - Timeouts   │     │              │                     │   │
│ │  └──────────────┘     └──────────────┘                     │   │
│ └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
│ ┌─────────────────────────────────────────────────────────────┐   │
│ │         CONNECTION POOL                                     │   │
│ │  - Serial connections (USB→RS232)                           │   │
│ │  - TCP connections (TCP/IP bridges)                         │   │
│ │  - Connection reuse & pooling                               │   │
│ │  - Reconnection with exponential backoff                    │   │
│ └─────────────────────────────────────────────────────────────┘   │
│                                                                     │
└────────────────────────────────┬─────────────────────────────────┘
                                 │
┌────────────────────────────────▼─────────────────────────────────┐
│               CAPA DE PERSISTENCIA                                │
├────────────────────────────────────────────────────────────────┤
│                                                                 │
│  PostgreSQL (Production)                                       │
│  ┌──────────────────────────────────────────────────────────┐ │
│  │ - inverters (master)                                      │ │
│  │ - inverter_parameters (configuración dinámica)            │ │
│  │ - inverter_readings (histórico de datos)                  │ │
│  │ - inverter_alerts (alertas generadas)                     │ │
│  │ - reports (reportes pre-generados)                        │ │
│  │ - users (autenticación)                                   │ │
│  │ - audit_logs (trazabilidad)                               │ │
│  └──────────────────────────────────────────────────────────┘ │
│                                                                 │
│  Redis (Cache + Session Store)                                 │
│  ┌──────────────────────────────────────────────────────────┐ │
│  │ - inverter:config:{id}  (configuración en caché)          │ │
│  │ - inverter:status:{id}  (último estado)                   │ │
│  │ - session:*             (sesiones de usuario)             │ │
│  │ - alert:queue           (cola de alertas)                 │ │
│  └──────────────────────────────────────────────────────────┘ │
│                                                                 │
└────────────────────────────────┬────────────────────────────────┘
                                 │
┌────────────────────────────────▼─────────────────────────────────┐
│                  CAPA DE DISPOSITIVOS                             │
├────────────────────────────────────────────────────────────────┤
│                                                                 │
│  Inversores Felicity (hasta 200)                               │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ...               │
│  │INV-001   │  │INV-002   │  │INV-003   │                    │
│  │RS485/RJ45│  │Serial    │  │TCP/IP    │                    │
│  └──────────┘  └──────────┘  └──────────┘                    │
│                                                                 │
└────────────────────────────────────────────────────────────────┘
```

### Stack Tecnológico

| Capa | Tecnología | Razón |
|------|------------|-------|
| **Frontend Web** | React 18 + TypeScript + Vite | Moderno, type-safe, rápido |
| **Frontend Móvil** | Flutter + Dart | Cross-platform (iOS/Android) |
| **Backend** | Spring Boot 3.x + Java 17 | Maduro, escalable, JHipster support |
| **Base de Datos** | PostgreSQL | Relacional, confiable, ACID |
| **Cache** | Redis | Sesiones, configuración dinámica |
| **Real-time** | WebSocket (STOMP) | Streaming de datos sin latencia |
| **Autenticación** | JWT + OAuth2 (opcional) | Stateless, seguro |
| **Reportes** | iText / Apache POI | Generación PDF/Excel |
| **Contenedores** | Docker + Docker Compose | Despliegue reproducible |
| **CI/CD** | GitHub Actions | Automatización de tests y deployment |

---

## 📊 ESPECIFICACIÓN DE BASE DE DATOS (JDL)

```jdl
// ============================================
// PRD: FELICITY SOLAR MONITOR - JDL MODEL
// ============================================
// Este archivo JDL puede ser usado directamente
// con JHipster para generar la aplicación base

// ============================================
// 1. GESTIÓN DE USUARIOS Y AUTENTICACIÓN
// ============================================

entity User {
    id Long
    email String required unique
    password String required
    firstName String
    lastName String
    phone String
    role Role
    isActive Boolean default true
    createdAt LocalDateTime
    updatedAt LocalDateTime
}

enum Role {
    ADMIN,
    OPERATOR,
    VIEWER,
    TECHNICIAN
}

entity UserPermission {
    id Long
    userId Long
    permission Permission
    grantedAt LocalDateTime
}

enum Permission {
    VIEW_DASHBOARD,
    VIEW_REPORTS,
    CONFIGURE_INVERTERS,
    CONFIGURE_ALERTS,
    MANAGE_USERS,
    EXPORT_DATA,
    WRITE_COMMANDS
}

// ============================================
// 2. GESTIÓN DE INVERSORES
// ============================================

entity Inverter {
    id Long
    inverterId String required unique maxlength(50)
    serialNumber String
    brand String // "Felicity", "Axpert", etc.
    model String // "3KW", "5KW", etc.
    location String // Descripción de ubicación
    latitude Double
    longitude Double
    modbusAddress Integer required default 1 // 0x01 - 0xFF
    connectionType ConnectionType
    ipAddress String
    port Integer
    serialPort String // COM3, /dev/ttyUSB0
    baudRate Integer default 2400
    pollingInterval Integer default 5 // segundos
    isActive Boolean default true
    lastSeen LocalDateTime
    createdAt LocalDateTime
    updatedAt LocalDateTime
}

enum ConnectionType {
    SERIAL_USB,
    SERIAL_RS485,
    TCP_IP_BRIDGE,
    TCP_IP_DIRECT
}

entity InverterStatus {
    id Long
    inverterId Long required
    workingMode WorkingMode
    batteryVoltage Double
    batteryCurrent Double
    batterySOC Integer
    pvVoltage Double
    pvCurrent Double
    pvPower Long
    acVoltage Double
    acCurrent Double
    acPower Long
    gridVoltage Double
    frequency Double
    temperature Integer
    efficiency Double
    isOnline Boolean default true
    lastReadTime LocalDateTime
    readingDuration Long // ms
}

enum WorkingMode {
    PV_CHARGING,
    PV_SUPPLY,
    BATTERY_SUPPLY,
    GRID_CHARGING,
    GRID_SUPPLY,
    IDLE,
    FAULT,
    UNKNOWN
}

entity InverterReading {
    id Long
    inverterId Long required
    timestamp LocalDateTime
    parameter String // "voltage_battery", "current_pv", etc.
    value Double
    unit String
    status ReadingStatus
}

enum ReadingStatus {
    NORMAL,
    WARNING,
    CRITICAL,
    ERROR
}

// ============================================
// 3. CONFIGURACIÓN DINÁMICA DE PARÁMETROS
// ============================================

entity ParameterTemplate {
    id Long
    name String required
    brand String required
    model String required
    description String
    isActive Boolean default true
    createdAt LocalDateTime
    updatedAt LocalDateTime
}

entity TemplateParameter {
    id Long
    templateId Long required
    parameterName String required // "voltage_battery", "current_pv", etc.
    registerAddress String required // "0x1108", "4361", etc.
    dataType DataType
    unit String
    scaleMultiplier Double default 1.0
    displayFormat String // "#0.00", "###,##0", etc.
    minValue Double
    maxValue Double
    enabledByDefault Boolean default true
    description String
}

enum DataType {
    UINT16,
    INT16,
    UINT32,
    INT32,
    FLOAT,
    STRING
}

entity InverterParameterConfig {
    id Long
    inverterId Long required
    parameterName String required
    isEnabled Boolean default true
    warningThreshold Double
    alarmThreshold Double
    notificationEnabled Boolean default true
    lastModified LocalDateTime
    modifiedBy Long // userId
}

entity ParameterThreshold {
    id Long
    inverterId Long
    parameterName String required
    warningMin Double
    warningMax Double
    alarmMin Double
    alarmMax Double
    criticalMin Double
    criticalMax Double
}

// ============================================
// 4. ALERTAS Y NOTIFICACIONES
// ============================================

entity Alert {
    id Long
    inverterId Long required
    parameterName String
    severity AlertSeverity
    message String
    value Double
    threshold Double
    triggeredAt LocalDateTime
    resolvedAt LocalDateTime
    status AlertStatus
    acknowledgedBy Long // userId
    acknowledgedAt LocalDateTime
}

enum AlertSeverity {
    INFO,
    WARNING,
    CRITICAL,
    EMERGENCY
}

enum AlertStatus {
    ACTIVE,
    ACKNOWLEDGED,
    RESOLVED,
    DISMISSED
}

entity NotificationLog {
    id Long
    alertId Long
    userId Long
    channel NotificationChannel
    sentAt LocalDateTime
    deliveryStatus DeliveryStatus
    message String
}

enum NotificationChannel {
    IN_APP,
    EMAIL,
    SMS,
    PUSH_NOTIFICATION
}

enum DeliveryStatus {
    PENDING,
    SENT,
    DELIVERED,
    FAILED
}

entity AlertRule {
    id Long
    name String required
    description String
    condition AlertCondition
    severity AlertSeverity
    isActive Boolean default true
    notifyEmail Boolean default false
    notifyPush Boolean default true
    createdAt LocalDateTime
    updatedAt LocalDateTime
}

enum AlertCondition {
    BELOW_THRESHOLD,
    ABOVE_THRESHOLD,
    EQUALS_VALUE,
    RANGE_VIOLATION,
    STATUS_CHANGE,
    CONNECTION_LOST
}

// ============================================
// 5. REPORTES Y ANÁLISIS
// ============================================

entity Report {
    id Long
    inverterId Long required
    reportType ReportType
    periodStart LocalDateTime
    periodEnd LocalDateTime
    energyGenerated Double // kWh
    peakEfficiency Double // %
    averageEfficiency Double // %
    operatingHours Double
    downtime Long // segundos
    degradation Double // %
    availabilityPercent Double // %
    maxTemperature Integer
    minTemperature Integer
    averageTemperature Double
    createdAt LocalDateTime
    filePath String // para almacenar PDF/Excel
}

enum ReportType {
    DAILY,
    WEEKLY,
    MONTHLY,
    QUARTERLY,
    ANNUAL,
    CUSTOM
}

entity DailyEnergyLog {
    id Long
    inverterId Long required
    logDate LocalDate
    energyGenerated Double
    energyFromBattery Double
    energyFromGrid Double
    energyToGrid Double
    operatingHours Double
    peakPower Long
    averagePower Long
    temperature Integer
    efficiency Double
}

entity PerformanceMetric {
    id Long
    inverterId Long required
    metricDate LocalDateTime
    pr Double // Performance Ratio
    cuf Double // Capacity Utilization Factor
    soiling Double // Soiling Losses %
    temperatureLosses Double
    degradationRate Double // % per month
}

// ============================================
// 6. AUDITORÍA Y SEGURIDAD
// ============================================

entity AuditLog {
    id Long
    userId Long
    entityType String
    entityId Long
    action String // CREATE, UPDATE, DELETE
    oldValue String
    newValue String
    timestamp LocalDateTime
    ipAddress String
    userAgent String
}

entity SystemLog {
    id Long
    level LogLevel
    component String
    message String
    stackTrace String
    timestamp LocalDateTime
}

enum LogLevel {
    DEBUG,
    INFO,
    WARN,
    ERROR,
    FATAL
}

// ============================================
// 7. CONFIGURACIÓN DEL SISTEMA
// ============================================

entity SystemConfig {
    id Long
    configKey String required unique
    configValue String
    dataType String
    description String
    isEditable Boolean default true
    lastModified LocalDateTime
}

entity DeviceConnection {
    id Long
    inverterId Long required
    connectionId String unique
    lastConnectedAt LocalDateTime
    lastDisconnectedAt LocalDateTime
    connectionDuration Long // ms
    failureCount Integer default 0
    successCount Integer default 0
}

// ============================================
// 8. RELACIONES
// ============================================

relationship OneToMany {
    User to UserPermission
    User to AuditLog
    ParameterTemplate to TemplateParameter
    Inverter to InverterStatus
    Inverter to InverterReading
    Inverter to InverterParameterConfig
    Inverter to ParameterThreshold
    Inverter to Alert
    Inverter to Report
    Inverter to DailyEnergyLog
    Inverter to PerformanceMetric
    Inverter to DeviceConnection
    Alert to NotificationLog
}

relationship ManyToOne {
    InverterParameterConfig to User { modifiedBy }
    Alert to User { acknowledgedBy }
    NotificationLog to User { userId }
}

// ============================================
// OPCIONES DE JHIPSTER
// ============================================

dto * with mapstruct
service * with serviceClass
paginate * with pagination
filter *

// Blockchain/Audit
skipClient
skipServer false
```

---

## 🔌 API REST + WEBSOCKET

### REST API Endpoints

#### **Gestión de Inversores**

```
GET    /api/inverters                          # Listar todos
POST   /api/inverters                          # Crear nuevo
GET    /api/inverters/{id}                     # Obtener uno
PUT    /api/inverters/{id}                     # Actualizar
DELETE /api/inverters/{id}                     # Eliminar (soft)
POST   /api/inverters/bulk-import              # Importar CSV
GET    /api/inverters/{id}/status              # Estado actual
```

#### **Configuración de Parámetros**

```
GET    /api/inverters/{id}/parameters          # Params del inversor
GET    /api/templates                          # Plantillas disponibles
POST   /api/templates                          # Crear plantilla
GET    /api/inverters/{id}/parameters/{name}   # Parámetro específico
PUT    /api/inverters/{id}/parameters/{name}   # Editar parámetro
DELETE /api/inverters/{id}/parameters/{name}   # Desactivar parámetro
```

#### **Monitoreo en Tiempo Real**

```
WebSocket /ws/inverters/{id}                   # Stream de un inversor
WebSocket /ws/dashboard                        # Stream de todos
```

#### **Alertas**

```
GET    /api/alerts                             # Listar alertas activas
GET    /api/alerts?status=RESOLVED              # Histórico
PUT    /api/alerts/{id}/acknowledge            # Marcar como vista
POST   /api/alerts/{id}/dismiss                # Descartar alerta
POST   /api/alert-rules                        # Crear regla
```

#### **Reportes**

```
GET    /api/inverters/{id}/reports             # Reportes disponibles
POST   /api/inverters/{id}/reports/generate    # Generar reporte
GET    /api/inverters/{id}/reports/{reportId}/download
GET    /api/reports/dashboard                  # Dashboard analytics
GET    /api/inverters/{id}/efficiency          # Análisis eficiencia
```

---

### WebSocket Events

#### **Del Servidor al Cliente**

```javascript
// Datos en vivo
{
  type: "INVERTER_STATUS_UPDATE",
  inverterId: "INV-001",
  timestamp: "2024-05-10T14:32:45.123Z",
  data: {
    status: "CHARGING_BATTERY",
    batteryVoltage: 48.2,
    batteryCurrent: 45.3,
    pvPower: 3500,
    acPower: 2800,
    temperature: 38,
    efficiency: 0.94
  }
}

// Configuración actualizada
{
  type: "CONFIG_UPDATED",
  inverterId: "INV-001",
  parameters: [...]
}

// Alerta generada
{
  type: "ALERT_TRIGGERED",
  inverterId: "INV-001",
  alertId: 12345,
  severity: "WARNING",
  message: "Voltaje de batería bajo: 45V"
}

// Conexión perdida
{
  type: "INVERTER_OFFLINE",
  inverterId: "INV-001",
  lastSeen: "2024-05-10T14:30:00.000Z"
}

// Reconexión
{
  type: "INVERTER_ONLINE",
  inverterId: "INV-001",
  connectedAt: "2024-05-10T14:35:00.000Z"
}
```

#### **Del Cliente al Servidor**

```javascript
// Suscribirse a actualizaciones
{
  type: "SUBSCRIBE",
  inverterId: "INV-001"
}

// Solicitar status inmediato
{
  type: "FORCE_READ",
  inverterId: "INV-001"
}

// Cambiar parámetro
{
  type: "UPDATE_PARAMETER",
  inverterId: "INV-001",
  parameterName: "warningThreshold",
  value: 45
}

// Desuscribirse
{
  type: "UNSUBSCRIBE",
  inverterId: "INV-001"
}
```

---

## 🎨 FRONTEND REACT

### Estructura de Carpetas

```
frontend/
├── src/
│   ├── components/
│   │   ├── Dashboard/
│   │   │   ├── InverterGrid.tsx
│   │   │   ├── InverterCard.tsx
│   │   │   └── Dashboard.tsx
│   │   ├── InverterDetail/
│   │   │   ├── InverterDetail.tsx
│   │   │   ├── RealTimeChart.tsx
│   │   │   └── ParameterList.tsx
│   │   ├── Config/
│   │   │   ├── ParameterConfig.tsx
│   │   │   ├── ThresholdEditor.tsx
│   │   │   └── TemplateManager.tsx
│   │   ├── Alerts/
│   │   │   ├── AlertPanel.tsx
│   │   │   └── AlertHistory.tsx
│   │   ├── Reports/
│   │   │   ├── ReportGenerator.tsx
│   │   │   └── ReportViewer.tsx
│   │   └── Common/
│   │       ├── Header.tsx
│   │       ├── Sidebar.tsx
│   │       └── StatusBadge.tsx
│   ├── hooks/
│   │   ├── useWebSocket.ts
│   │   ├── useInverters.ts
│   │   └── useAlerts.ts
│   ├── services/
│   │   ├── api.ts (Axios instance)
│   │   ├── inverterService.ts
│   │   ├── reportService.ts
│   │   └── webSocketService.ts
│   ├── store/
│   │   ├── inverterStore.ts (Zustand)
│   │   ├── uiStore.ts
│   │   └── alertStore.ts
│   ├── styles/
│   │   ├── globals.css
│   │   └── Dashboard.module.css
│   └── App.tsx
└── package.json
```

### Componentes Principales

#### **Dashboard (Grid View)**

```typescript
// Dashboard.tsx
import React, { useEffect } from 'react';
import { useInverterStore } from '../store/inverterStore';
import InverterCard from './InverterCard';
import { useWebSocketService } from '../hooks/useWebSocket';

export function Dashboard() {
  const inverters = useInverterStore(s => s.inverters);
  const { connect } = useWebSocketService();

  useEffect(() => {
    connect(); // Conectar WebSocket
  }, []);

  return (
    <div className="dashboard-grid">
      <h1>Monitoreo de Inversores ({inverters.length})</h1>
      <div className="grid-container">
        {inverters.map(inv => (
          <InverterCard key={inv.id} inverter={inv} />
        ))}
      </div>
    </div>
  );
}
```

#### **Tarjeta de Inversor (Real-time)**

```typescript
// InverterCard.tsx
export function InverterCard({ inverter }) {
  const status = useInverterStore(s => s.statusMap[inverter.id]);
  
  return (
    <div className={`card ${status?.isOnline ? 'online' : 'offline'}`}>
      <div className="header">
        <h3>{inverter.inverterId}</h3>
        <StatusBadge status={status?.workingMode} />
      </div>
      
      <div className="metrics">
        <Metric label="Voltaje" value={status?.batteryVoltage} unit="V" />
        <Metric label="Corriente" value={status?.batteryCurrent} unit="A" />
        <Metric label="Potencia PV" value={status?.pvPower} unit="W" />
        <Metric label="Potencia AC" value={status?.acPower} unit="W" />
        <Metric label="Eficiencia" value={status?.efficiency} unit="%" />
        <Metric label="Temperatura" value={status?.temperature} unit="°C" />
      </div>

      <div className="chart">
        <RealTimeChart inverterId={inverter.id} />
      </div>
    </div>
  );
}
```

#### **Gráfico en Vivo (Recharts)**

```typescript
// RealTimeChart.tsx
import { LineChart, Line, XAxis, YAxis, Tooltip } from 'recharts';

export function RealTimeChart({ inverterId }) {
  const chartData = useInverterStore(s => s.chartData[inverterId] || []);

  return (
    <LineChart width={300} height={150} data={chartData}>
      <XAxis dataKey="time" />
      <YAxis />
      <Tooltip />
      <Line
        type="monotone"
        dataKey="power"
        stroke="#8884d8"
        isAnimationActive={true}
      />
    </LineChart>
  );
}
```

---

## 📱 APP FLUTTER

### Estructura de Proyecto

```
flutter_app/
├── lib/
│   ├── main.dart
│   ├── config/
│   │   ├── constants.dart
│   │   └── theme.dart
│   ├── models/
│   │   ├── inverter_model.dart
│   │   ├── inverter_status.dart
│   │   └── alert_model.dart
│   ├── providers/
│   │   ├── inverter_provider.dart
│   │   ├── websocket_provider.dart
│   │   └── notification_provider.dart
│   ├── screens/
│   │   ├── login_screen.dart
│   │   ├── dashboard_screen.dart
│   │   ├── inverter_detail_screen.dart
│   │   ├── alerts_screen.dart
│   │   ├── reports_screen.dart
│   │   └── settings_screen.dart
│   ├── widgets/
│   │   ├── inverter_tile.dart
│   │   ├── metric_card.dart
│   │   ├── battery_gauge.dart
│   │   └── chart_widget.dart
│   ├── services/
│   │   ├── api_service.dart
│   │   ├── websocket_service.dart
│   │   ├── local_storage_service.dart
│   │   └── notification_service.dart
│   └── utils/
│       ├── validators.dart
│       └── formatters.dart
├── pubspec.yaml
└── android/
    └── app/build.gradle
```

### Pantallas Principales

#### **Login Screen**

```dart
// login_screen.dart
class LoginScreen extends StatefulWidget {
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Felicity Monitor')),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset('assets/logo.png', width: 120),
            SizedBox(height: 32),
            TextField(
              controller: _emailController,
              decoration: InputDecoration(
                labelText: 'Correo',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 16),
            TextField(
              controller: _passwordController,
              obscureText: true,
              decoration: InputDecoration(
                labelText: 'Contraseña',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 24),
            ElevatedButton(
              onPressed: _login,
              child: Text('Ingresar'),
            ),
          ],
        ),
      ),
    );
  }

  void _login() async {
    final provider = Provider.of<AuthProvider>(context, listen: false);
    await provider.login(
      _emailController.text,
      _passwordController.text,
    );
    if (provider.isAuthenticated) {
      Navigator.of(context).pushReplacementNamed('/dashboard');
    }
  }
}
```

#### **Dashboard Mobile**

```dart
// dashboard_screen.dart
class DashboardScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Panel de Control'),
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: () => _refreshData(context),
          ),
        ],
      ),
      body: Consumer<InverterProvider>(
        builder: (context, provider, _) {
          if (provider.isLoading) {
            return Center(child: CircularProgressIndicator());
          }

          return ListView.builder(
            itemCount: provider.inverters.length,
            itemBuilder: (context, index) {
              final inverter = provider.inverters[index];
              return InverterTile(
                inverter: inverter,
                onTap: () => Navigator.pushNamed(
                  context,
                  '/inverter-detail',
                  arguments: inverter.id,
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _refreshData(context),
        child: Icon(Icons.refresh),
      ),
    );
  }

  void _refreshData(BuildContext context) {
    Provider.of<InverterProvider>(context, listen: false).fetchInverters();
  }
}
```

#### **Detalle de Inversor**

```dart
// inverter_detail_screen.dart
class InverterDetailScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final inverterId = ModalRoute.of(context)!.settings.arguments as int;

    return Scaffold(
      appBar: AppBar(title: Text('Detalle Inversor')),
      body: Consumer<InverterProvider>(
        builder: (context, provider, _) {
          final inverter = provider.getInverterById(inverterId);
          if (inverter == null) {
            return Center(child: Text('Inversor no encontrado'));
          }

          return SingleChildScrollView(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Estado general
                  Card(
                    child: Padding(
                      padding: EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            inverter.inverterId,
                            style: Theme.of(context).textTheme.titleLarge,
                          ),
                          SizedBox(height: 8),
                          Row(
                            children: [
                              Chip(
                                label: Text(inverter.location),
                                avatar: Icon(Icons.location_on),
                              ),
                              SizedBox(width: 8),
                              Chip(
                                label: Text(
                                  inverter.isOnline ? 'Online' : 'Offline',
                                ),
                                backgroundColor: inverter.isOnline
                                    ? Colors.green
                                    : Colors.red,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(height: 16),

                  // Batería
                  BatteryGauge(
                    voltage: inverter.status?.batteryVoltage ?? 0,
                    soc: inverter.status?.batterySOC ?? 0,
                  ),
                  SizedBox(height: 16),

                  // Métricas
                  GridView.count(
                    crossAxisCount: 2,
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    children: [
                      MetricCard(
                        label: 'Potencia PV',
                        value: '${inverter.status?.pvPower ?? 0} W',
                        icon: Icons.wb_sunny,
                      ),
                      MetricCard(
                        label: 'Potencia AC',
                        value: '${inverter.status?.acPower ?? 0} W',
                        icon: Icons.electric_bolt,
                      ),
                      MetricCard(
                        label: 'Temperatura',
                        value: '${inverter.status?.temperature ?? 0}°C',
                        icon: Icons.thermostat,
                      ),
                      MetricCard(
                        label: 'Eficiencia',
                        value: '${(inverter.status?.efficiency ?? 0 * 100).toStringAsFixed(1)}%',
                        icon: Icons.trending_up,
                      ),
                    ],
                  ),
                  SizedBox(height: 16),

                  // Gráfico
                  Text('Histórico (últimas 24h)', style: Theme.of(context).textTheme.titleMedium),
                  SizedBox(height: 8),
                  ChartWidget(inverterId: inverterId),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
```

### pubspec.yaml

```yaml
name: felicity_monitor
description: App de monitoreo para inversores solares Felicity

publish_to: 'none'

version: 1.0.0+1

environment:
  sdk: '>=3.0.0 <4.0.0'

dependencies:
  flutter:
    sdk: flutter
  
  # HTTP & WebSocket
  http: ^1.1.0
  web_socket_channel: ^2.4.0
  
  # State Management
  provider: ^6.0.0
  
  # Storage
  shared_preferences: ^2.2.0
  sqflite: ^2.3.0
  
  # UI
  cupertino_icons: ^1.0.2
  intl: ^0.19.0
  
  # Charts
  fl_chart: ^0.65.0
  
  # Notifications
  firebase_core: ^2.24.0
  firebase_messaging: ^14.6.0
  
  # Auth
  jwt_decoder: ^2.0.1
  
  # Logging
  logger: ^2.0.0

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^3.0.0

flutter:
  uses-material-design: true

  assets:
    - assets/logo.png
    - assets/icons/
```

---

## 📊 REPORTES Y ANÁLISIS

### Tipos de Reportes

#### **1. Reporte Diario**

```
┌─────────────────────────────────────────┐
│ REPORTE DIARIO - 10 de Mayo 2024        │
│ Inversor: INV-001                       │
├─────────────────────────────────────────┤
│                                         │
│ PRODUCCIÓN:                             │
│  - Energía generada: 24.5 kWh          │
│  - Energía desde batería: 8.2 kWh      │
│  - Energía desde red: 0 kWh             │
│  - Energía a red: 0 kWh                 │
│                                         │
│ RENDIMIENTO:                            │
│  - Eficiencia promedio: 94.2%           │
│  - Eficiencia máxima: 96.8%             │
│  - Eficiencia mínima: 89.3%             │
│  - Horas de operación: 10.5 h           │
│                                         │
│ TEMPERATURA:                            │
│  - Máxima: 48°C                         │
│  - Mínima: 22°C                         │
│  - Promedio: 35.2°C                     │
│                                         │
│ DISPONIBILIDAD:                         │
│  - Uptime: 99.8%                        │
│  - Eventos de desconexión: 1            │
│  - Duración eventos: 14 min             │
│                                         │
└─────────────────────────────────────────┘
```

#### **2. Reporte Mensual**

```json
{
  "reportId": "RPT-2024-05-INV-001",
  "period": "Mayo 2024",
  "inverter": "INV-001",
  "summary": {
    "totalEnergyGenerated": 735.2,
    "averageDailyProduction": 23.7,
    "totalOperatingHours": 310.5,
    "availability": 99.6,
    "degradation": 0.12
  },
  "efficiency": {
    "average": 94.1,
    "max": 97.2,
    "min": 88.5,
    "std_dev": 1.8
  },
  "temperature": {
    "max": 52,
    "min": 15,
    "average": 35.8
  },
  "downtime_events": [
    {
      "date": "2024-05-15",
      "duration_min": 23,
      "reason": "Maintenance window"
    }
  ],
  "alerts": {
    "warnings": 3,
    "critical": 0,
    "resolved": 100
  },
  "forecast_vs_actual": {
    "forecast": 750.0,
    "actual": 735.2,
    "variance": -1.97,
    "variance_reason": "Lower irradiance due to weather"
  }
}
```

#### **3. Dashboard Analítico**

```
┌────────────────────────────────────────────────────────┐
│       DASHBOARD ANALÍTICO - Todos los Inversores       │
├────────────────────────────────────────────────────────┤
│                                                        │
│  KPIs GENERALES:                                      │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐
│  │ Total GW     │  │ Avg Eff      │  │ Uptime       │
│  │ 5,423 kWh    │  │ 93.8%        │  │ 99.7%        │
│  └──────────────┘  └──────────────┘  └──────────────┘
│                                                        │
│  COMPARATIVA POR INVERSOR:                            │
│  ┌────────┬──────────┬────────┬──────────┐            │
│  │ID      │Prod (kWh)│Eff (%) │Uptime (%)│            │
│  ├────────┼──────────┼────────┼──────────┤            │
│  │INV-001 │ 735.2    │ 94.1   │ 99.6     │            │
│  │INV-002 │ 712.8    │ 92.3   │ 99.8     │            │
│  │INV-003 │ 698.5    │ 93.5   │ 98.9     │            │
│  │...     │ ...      │ ...    │ ...      │            │
│  └────────┴──────────┴────────┴──────────┘            │
│                                                        │
│  TENDENCIAS:                                          │
│  [Gráfico de producción semanal]                      │
│  [Gráfico de eficiencia vs temperatura]               │
│  [Gráfico de degradación acumulada]                   │
│                                                        │
└────────────────────────────────────────────────────────┘
```

### Algoritmo de Cálculo de Métricas

#### **Eficiencia Instantánea**

```python
def calculate_efficiency(power_dc, power_ac):
    """
    Eficiencia = Potencia AC / Potencia DC
    Normalmente > 92% en Felicity
    """
    if power_dc == 0:
        return 0
    return (power_ac / power_dc) * 100

# Ejemplo:
# Si PV genera 3500W y AC saca 3290W
# Eficiencia = 3290/3500 * 100 = 94%
```

#### **Degradación Anual**

```python
def calculate_annual_degradation(readings_month1, readings_month12):
    """
    Degradación % = (Energía_Mes1 - Energía_Mes12) / Energía_Mes1 / 12
    Típica: 0.5-0.8% anual
    Alerta: > 1.5% anual
    """
    avg_production_m1 = sum(readings_month1) / len(readings_month1)
    avg_production_m12 = sum(readings_month12) / len(readings_month12)
    
    degradation = (
        (avg_production_m1 - avg_production_m12) / avg_production_m1
    ) * 100 / 12
    
    return degradation
```

#### **Factor de Desempeño (PR)**

```python
def calculate_pr(actual_energy, expected_energy):
    """
    Performance Ratio (PR) = Energía Real / Energía Esperada
    Indica la salud del sistema
    Ideal: > 75% (depende de ubicación y clima)
    """
    if expected_energy == 0:
        return 0
    return (actual_energy / expected_energy) * 100
```

---

## 🚀 ROADMAP DE IMPLEMENTACIÓN

### **FASE 1: CORE + API (Semanas 1-4)**

#### Sprint 1-2: Backend Base
- [ ] Configurar proyecto Spring Boot 3.x + JHipster
- [ ] Generar entidades desde JDL
- [ ] Configurar PostgreSQL
- [ ] Implementar autenticación JWT
- [ ] Crear repositorios y servicios CRUD básicos
- [ ] Tests unitarios para servicios

**Entregables:**
- API REST funcional para CRUD de inversores
- Base de datos configurada
- Tests > 80% cobertura

#### Sprint 3: Modbus RTU
- [ ] Implementar Modbus RTU client
- [ ] Parser de registros Felicity
- [ ] Validación de checksums CRC-16
- [ ] Connection pool manager
- [ ] Tests de integración con simulador

**Entregables:**
- Lectura exitosa de parámetros desde inversor de prueba
- Manejo de errores y timeouts
- Documentación técnica

#### Sprint 4: Configurabilidad Dinámica
- [ ] Servicio de plantillas de parámetros
- [ ] Servicio de configuración por inversor
- [ ] Caché Redis de configuraciones
- [ ] Validación de umbrales
- [ ] Historial de cambios

**Entregables:**
- UI para definir y editar parámetros
- Cambios sin reiniciar
- Auditoría de cambios

---

### **FASE 2: MONITOREO EN TIEMPO REAL (Semanas 5-8)**

#### Sprint 5: Polling Service
- [ ] Background polling con ScheduledExecutorService
- [ ] Manejo de múltiples inversores
- [ ] Exponential backoff en reconnexión
- [ ] Logging detallado

#### Sprint 6: WebSocket
- [ ] Configurar Spring WebSocket + STOMP
- [ ] Handlers para conexión/desconexión
- [ ] Broadcasting de datos
- [ ] Compresión JSON

#### Sprint 7: Dashboard React
- [ ] Setup Vite + React + TypeScript
- [ ] Componentes reutilizables
- [ ] Zustand store
- [ ] Integración WebSocket

#### Sprint 8: Gráficos en Vivo
- [ ] Recharts integration
- [ ] Histórico de últimas 24h
- [ ] Alertas visuales
- [ ] Responsive design

**Entregables:**
- Dashboard web funcional
- Datos en vivo con <1s latencia
- Móvil responsive

---

### **FASE 3: ALERTAS + REPORTES (Semanas 9-12)**

#### Sprint 9: Sistema de Alertas
- [ ] Servicio de evaluación de umbrales
- [ ] Motor de alertas con reglas
- [ ] Notificaciones email/push
- [ ] Historial de alertas

#### Sprint 10: Reportes Básicos
- [ ] Generación diaria de reportes
- [ ] Cálculo de métricas de eficiencia
- [ ] Exportación a PDF
- [ ] Scheduler de generación

#### Sprint 11: Flutter App
- [ ] Setup Flutter project
- [ ] Login y autenticación
- [ ] Dashboard móvil
- [ ] Integración WebSocket

#### Sprint 12: Pulido y Testing
- [ ] E2E tests
- [ ] Performance testing
- [ ] Security audit
- [ ] Documentación

**Entregables:**
- App completa de monitoreo
- Reportes básicos
- APK de Flutter

---

### **FASE 4+: MEJORAS Y ESCALABILIDAD**

- [ ] Soporte para múltiples marcas (Axpert, etc)
- [ ] Machine Learning para predicción de fallas
- [ ] API pública para integraciones
- [ ] Multi-tenencia
- [ ] Integración IoT (medidores, sensores)

---

## 📈 KPIs Y MÉTRICAS

### Para el Operador

| KPI | Definición | Meta | Frecuencia |
|-----|-----------|------|-----------|
| **Energy Generated (kWh)** | Total de energía producida | Según capacidad | Diario |
| **System Uptime (%)** | % de horas operativo | > 99.5% | Mensual |
| **Average Efficiency (%)** | Eficiencia promedio | > 93% | Diario |
| **Degradation Rate (%)** | Pérdida anual | < 0.8% | Anual |
| **MTBF (horas)** | Tiempo medio entre fallos | > 8760 h | Trimestral |
| **Alert Response Time (min)** | Tiempo para resolver alerta | < 30 min | Ongoing |
| **Data Collection Frequency (s)** | Cada cuanto se leen datos | 5 s | Real-time |

### Para la Plataforma

| Métrica | Objetivo | Herramienta |
|---------|----------|-------------|
| **Latencia WebSocket** | < 1 segundo | Prometheus |
| **API Response Time** | < 200ms (p95) | New Relic |
| **Database Query Time** | < 100ms (p99) | PostgreSQL EXPLAIN |
| **Memory Usage** | < 2GB (backend) | Docker stats |
| **CPU Usage** | < 40% | Micrometer |
| **Uptime Plataforma** | 99.9% | Datadog |
| **Data Loss** | 0% (ACID) | PostgreSQL WAL |

---

## 📚 CONCLUSIÓN

Este PRD proporciona una **especificación técnica completa** para construir un sistema profesional de monitoreo solar. La arquitectura está diseñada para:

✅ **Escalabilidad**: Manejo de 200+ inversores sin degradación  
✅ **Configurabilidad**: Cada inversor puede tener parámetros únicos  
✅ **Confiabilidad**: Almacenamiento persistente y reconexión automática  
✅ **Usabilidad**: Interfaces intuitivas en web y móvil  
✅ **Analiticidad**: Reportes detallados para optimización  

### Próximos Pasos

1. **Revisar con stakeholders** - Validar requisitos
2. **Setup del proyecto** - JHipster + repositorios Git
3. **Comenzar Sprint 1** - Backend base
4. **Testing temprano** - Validar con inversor real
5. **Iteración rápida** - MVP en 8 semanas

---

**Documento Preparado Por:** Sistema de Expertos en Energía Solar  
**Última Actualización:** Mayo 2024  
**Versión:** 1.0 - FINAL
