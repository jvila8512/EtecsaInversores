# GUÍA PROFESIONAL: INVERSORES SOLARES FELICITY
## Parámetros Críticos, Configuración Óptima y Mejores Prácticas

---

## 📋 TABLA DE CONTENIDOS

1. [Principios de Inversores Solares](#principios)
2. [Parámetros Críticos a Monitorear](#parámetros)
3. [Configuración Óptima por Tipo de Sistema](#configuración)
4. [Diagnóstico de Problemas](#diagnóstico)
5. [Mejores Prácticas de Mantenimiento](#mantenimiento)
6. [Cálculos de Eficiencia](#cálculos)
7. [Especificaciones Técnicas Felicity](#especificaciones)

---

## 🔋 PRINCIPIOS DE INVERSORES SOLARES

### ¿Qué es un Inversor Solar Híbrido?

Un **inversor solar híbrido** es un dispositivo electrónico que:

1. **Convierte DC → AC**: Transforma la energía de paneles (corriente continua) a corriente alterna para usar en casa
2. **Gestiona batería**: Carga/descarga baterías según demanda y disponibilidad solar
3. **Conecta red**: Puede trabajar en paralelo o aislado de la red eléctrica

### Modos de Operación

```
MODO 1: PV-CHARGING (Carga desde Paneles)
────────────────────────────────────────
Paneles → Batería (+ carga directa si hay exceso)
Condiciones:
  - Radiación solar > 100 W/m²
  - Voltaje batería < 95% nominal
  - Horas: 6am - 4pm típicamente
Flujo:
  PV [3000W] ─┬─→ Batería [2000W]
              └─→ AC Output [1000W]

MODO 2: PV-SUPPLY (Alimentación desde Paneles)
──────────────────────────────────────────────
Paneles → Carga directa + Red (si hay exceso)
Ideal para:
  - Máxima auto-consumo (reduce energía de red)
  - Sistemas con feed-in enabled


MODO 3: BATTERY-SUPPLY (Batería → Carga)
─────────────────────────────────────────
Se activa cuando:
  - No hay sol (noche, días nublados)
  - Demanda > disponibilidad solar
  - Voltaje batería > 50% (típico)
Flujo:
  Batería [3000W] → AC Output [3000W]
  
Duración: Depende de capacidad (100Ah/48V = ~4.8kWh)


MODO 4: GRID-CHARGING (Red → Batería)
──────────────────────────────────────
Se activa cuando:
  - Batería descargada (< 30%)
  - Horario programado (tarifas bajas)
  - Noche
Corriente máxima típica: 30A (Felicity 5kW)


MODO 5: GRID-SUPPLY (Red → Carga)
─────────────────────────────────
Fallback cuando:
  - Batería agotada
  - Paneles no producen
  - Se requiere potencia > almacenada
```

### Transiciones de Modo

```
         ┌─────────────┐
         │   STARTUP   │
         └──────┬──────┘
                │ (Self-test OK)
         ┌──────▼──────┐
         │    IDLE     │
         └──────┬──────┘
                │
    ┌───────────┼───────────┐
    │           │           │
 PV Gen?    Batt Low?   Night?
    │           │           │
    ▼           ▼           ▼
 PV-CHG   GRID-CHG    GRID-SUPP
    │           │           │
    └───────────┼───────────┘
                │
         ┌──────▼──────┐
         │  DISCHARGE  │
         │  (AC Load)  │
         └──────┬──────┘
                │
         ┌──────▼──────┐
         │   FAULT     │
         │ (Shutdown)  │
         └─────────────┘
```

---

## ⚡ PARÁMETROS CRÍTICOS A MONITOREAR

### 1. BATERÍA (CRÍTICO - RIESGO DE DAÑO)

#### **Voltaje de Batería (V)**

| Rango | Estado | Acción | Riesgo |
|-------|--------|--------|--------|
| > 57V | Sobrecarga | ⚠️ Reducir carga | Oxidación, gas, muerte |
| 54-57V | Carga Normal | ✓ OK | - |
| 48-53V | Operativo | ✓ OK | - |
| 45-48V | Bajo | ⚠️ Monitorear | - |
| 40-44V | Crítico | 🔴 Alerta | Apagón inminente |
| < 40V | Falla | 🔴 ERROR | Sistema offline |

**Configuración recomendada (48V):**
```json
{
  "warning_threshold": 45,    // Alerta amarilla
  "alarm_threshold": 40,       // Alerta roja
  "cutoff_voltage": 38,        // Desconexión automática
  "float_voltage": 54.4        // Carga flotante
}
```

**Interpretación:**
- Voltaje bajo → Batería descargada, riesgo de apagón
- Voltaje cae lentamente → Carga normal en uso
- Voltaje cae rápidamente → Descarga rápida (falla probable)
- Voltaje no sube después de sunny day → Problema en carga

---

#### **Corriente de Batería (A)**

| Rango | Descripción | Interpretación |
|-------|-------------|-----------------|
| +150 A | Carga acelerada | PV > 7500W (raro) |
| +50 A | Carga normal | Solar midday típico |
| +5 A | Carga lenta | Solar débil |
| 0 A | Equilibrio | Consumo = generación |
| -50 A | Descarga moderada | Usando batería (noche) |
| -150 A | Descarga rápida | Pico de demanda |
| -200 A | CRÍTICO | ⚠️ Sobrecorriente |

**Monitoreo:**
- Corriente POSITIVA = cargando batería
- Corriente NEGATIVA = descargando batería
- Cambios bruscos = posible cortocircuito

**Alertas:**
```json
{
  "warning_threshold": 180,    // 180A carga/descarga
  "alarm_threshold": 200,      // 200A = falla inminente
  "max_charge_current": 150,   // Limitar carga
  "max_discharge_current": 180 // Limitar descarga
}
```

---

#### **State of Charge (SOC - %)**

| Rango | Estado | Vida Útil Anual | Acción |
|-------|--------|-----------------|--------|
| 100% | Lleno | Acelerada | Desconectar si posible |
| 80-90% | Normal | Normal | ✓ Óptimo |
| 50-80% | Operativo | Normal | ✓ Rango seguro |
| 20-50% | Bajo | Normal | Monitorear |
| 0-20% | Crítico | Acelerada | 🔴 Alerta |

**Por qué importa SOC:**
- Batería en 100% todo el día = envejece 5x más rápido
- Batería en 20-80% = máxima vida útil
- Ciclos profundos (0-100%) = degradación acelerada

**Configuración ideal:**
```json
{
  "max_soc": 95,           // No cargar por encima
  "min_soc": 20,           // No descargar más
  "optimal_range": [40, 80], // Rango recomendado
  "warning_threshold": 25,  // Alerta si baja
  "alarm_threshold": 10     // Alerta crítica
}
```

---

#### **Temperatura de Batería (°C)**

| Rango | Efecto | Acción |
|-------|--------|--------|
| < -10°C | Congelada | ⚠️ No cargar |
| -10 a 0°C | Muy fría | Carga lenta |
| 0 a 25°C | Normal | ✓ Óptimo |
| 25 a 40°C | Caliente | Monitorear |
| 40 a 50°C | Muy caliente | ⚠️ Degradación acelerada |
| > 50°C | CRÍTICO | 🔴 Riesgo de falla |
| > 60°C | Peligroso | 🔴 Apagar |

**Impacto en vida útil:**
- Cada 10°C sobre 25°C = vida útil se reduce a la mitad
- 35°C = envejecimiento normal
- 50°C = envejece 10x más rápido

**Configuración:**
```json
{
  "warning_temperature": 45,
  "alarm_temperature": 50,
  "critical_temperature": 60,
  "optimal_range": [15, 35],
  "freeze_protection": true,
  "enable_cooling": true
}
```

---

### 2. PANELES SOLARES (PV)

#### **Voltaje PV (V)**

| Voltaje | Estado | Interpretación |
|---------|--------|-----------------|
| 0-50V | No hay sol | Madrugada/atardecer |
| 50-150V | Sol débil | Mañana/atardecer |
| 150-350V | Sol normal | Mediodía |
| 350-400V | Sol fuerte | Pico solar |
| > 450V | Exceso (raro) | MPPT en límite |

**Cálculo teórico:**
```
Paneles 6kW típicos: 10 × 600W = 10 paneles
Voltaje serie: 48V nominal
Rango MPPT: 100-450V
```

---

#### **Potencia PV (W)**

**Correlación con irradiancia:**

```
Irradiancia (W/m²)  | Potencia Esperada | Situación
─────────────────────────────────────────────────────
0-100               | 0-10% nominal     | Nublado, madrugada
100-300             | 10-30%            | Mañana
300-600             | 30-70%            | Mañana/Tarde
600-800             | 70-90%            | Mediodía
800-1000            | 90-100%           | Pico solar
> 1000              | 100%+ (límite)    | Posible reflejo/nieve

Ejemplo (5kW sistema):
- 6am: 200W (10%)
- 8am: 1500W (30%)
- 12pm: 4800W (96%)
- 4pm: 2000W (40%)
- 6pm: 100W (2%)
```

**Detección de problemas:**

```json
{
  "expected_power": 5000,  // Potencia nominal
  "degradation_rate": 0.8, // % por año
  
  "alerts": {
    "low_production": {
      "threshold": 500,    // < 10% a mediodía
      "description": "Producción baja - revisar paneles"
    },
    "sudden_drop": {
      "drop_percentage": 30, // Caída > 30% en 1 min
      "description": "Nube rápida o sombra"
    }
  }
}
```

---

### 3. SALIDA AC (CRÍTICO - REGULA VOLTAJE/FRECUENCIA)

#### **Voltaje AC (V)**

| Voltaje | Estándar | Estado |
|---------|----------|--------|
| < 180V | Bajo | ⚠️ Alerta |
| 180-210V | Bajo-Normal | OK (tolerancia) |
| 210-240V | Normal | ✓ Ideal |
| 240-260V | Alto-Normal | OK (tolerancia) |
| > 260V | Alto | ⚠️ Alerta |

**Para diferentes países:**
- USA: 110-120V nominal (±10%)
- EU: 220-240V nominal (±10%)

**Configuración:**
```json
{
  "nominal_voltage": 240,
  "min_voltage": 216,       // 90% de nominal
  "max_voltage": 264,       // 110% de nominal
  "alarm_low": 200,
  "alarm_high": 280
}
```

---

#### **Frecuencia AC (Hz)**

**Estándar:**
- Europa, Australia, Latinoamérica: **50 Hz**
- USA, Canadá, Japón: **60 Hz**

| Frecuencia | Estado | Riesgo |
|-----------|--------|--------|
| < 49.5 Hz | Baja | ⚠️ Sub-frecuencia (apagón probable) |
| 49.5-50 Hz | Normal | ✓ OK |
| 50-50.5 Hz | Normal | ✓ OK |
| > 50.5 Hz | Alta | ⚠️ Sobre-frecuencia |

**Causa:**
- Baja frecuencia = demanda > generación en red
- Alta frecuencia = generación > demanda en red

**Inversor en 50Hz típico:**
```json
{
  "nominal_frequency": 50,
  "min_frequency": 49.5,
  "max_frequency": 50.5,
  "grid_support_enabled": true,
  "synchronization": "PLL_Locked"
}
```

---

### 4. EFICIENCIA (INDICADOR DE SALUD)

#### **Eficiencia Instantánea**

```
Eficiencia = (Potencia AC / Potencia PV) × 100

Ejemplo:
  PV genera: 4000W
  AC sale: 3760W
  Eficiencia = 94%
```

**Rango típico Felicity:**

| Eficiencia | Estado | Causa |
|-----------|--------|-------|
| > 96% | Excelente | Carga pura resistiva, condiciones ideales |
| 94-96% | Normal | ✓ Óptimo |
| 92-94% | Aceptable | Ligeras pérdidas de conversión |
| 90-92% | Bajo | ⚠️ Revisar componentes |
| < 90% | Muy bajo | 🔴 Posible falla |

**Factores que afectan eficiencia:**
- Temperatura (sube con calor)
- Carga resistiva vs inductiva
- Modulación PWM
- Envejecimiento electrolíticos

---

#### **Performance Ratio (PR)**

```
PR = (Energía Real / Energía Esperada) × 100

Cálculo:
  Energía Real = Historico de producción (kWh)
  Energía Esperada = POA irradiance × Area × Eficiencia panel

PR Benchmarks:
  > 80% = Excelente
  75-80% = Muy bien
  70-75% = Aceptable
  < 70% = Investigar degradación
```

---

## ⚙️ CONFIGURACIÓN ÓPTIMA POR TIPO DE SISTEMA

### Sistema Tipo 1: Conexión a Red (Grid-Tied)

**Uso:** Casa con acceso a red, sin batería

```json
{
  "system_type": "grid_tied_no_battery",
  "battery_enabled": false,
  "
grid_connected": true,
  
  "parameters": {
    "voltage_ac": {
      "enabled": true,
      "warning": 250,
      "alarm": 270
    },
    "frequency_ac": {
      "enabled": true,
      "warning": 50.5,
      "alarm": 51.0
    },
    "power_pv": {
      "enabled": true,
      "warning": null,
      "alarm": null
    },
    "power_output": {
      "enabled": true,
      "warning": null,
      "alarm": null
    }
  },
  
  "logging_interval": 300,  // 5 minutos
  "optimization": "maximum_autoconsumption"
}
```

---

### Sistema Tipo 2: Isla con Batería (Off-Grid)

**Uso:** Casa aislada sin acceso a red, con almacenamiento

```json
{
  "system_type": "off_grid_with_battery",
  "battery_enabled": true,
  "grid_connected": false,
  
  "parameters": {
    "voltage_battery": {
      "enabled": true,
      "warning": 45,
      "alarm": 40,
      "cutoff": 38
    },
    "current_battery": {
      "enabled": true,
      "warning": 180,
      "alarm": 200
    },
    "soc_battery": {
      "enabled": true,
      "min_soc": 20,
      "max_soc": 95
    },
    "temperature_battery": {
      "enabled": true,
      "warning": 45,
      "alarm": 50
    },
    "power_pv": {
      "enabled": true,
      "warning": null
    },
    "voltage_ac": {
      "enabled": true,
      "warning": 250,
      "alarm": 270
    }
  },
  
  "charging_strategy": "maximize_solar_utilization",
  "load_shedding_enabled": true,
  "load_shedding_soc": 10
}
```

---

### Sistema Tipo 3: Híbrido (Grid + Batería)

**Uso:** Casa con red + batería para backup/arbitraje

```json
{
  "system_type": "hybrid_grid_battery",
  "battery_enabled": true,
  "grid_connected": true,
  
  "priority_order": [
    "PV_CHARGING_BATTERY",
    "PV_SUPPLY_LOAD",
    "BATTERY_SUPPLY_LOAD",
    "GRID_SUPPLY_LOAD"
  ],
  
  "charge_times": {
    "grid_charge_enabled": true,
    "grid_charge_window": "23:00-06:00",  // Tarifas bajas
    "max_grid_charge_current": 30,
    "min_soc_before_grid_charge": 30
  },
  
  "discharge_times": {
    "discharge_enabled": true,
    "peak_shaving": {
      "enabled": true,
      "peak_hours": "19:00-21:00",
      "power_limit": 3000
    }
  },
  
  "arbitrage": {
    "enabled": true,
    "description": "Cargar en horas baratas, descargar en horas caras"
  }
}
```

---

## 🔍 DIAGNÓSTICO DE PROBLEMAS

### Problema 1: Baja Producción Solar

**Síntomas:**
- Potencia PV << esperada para hora del día
- Voltaje PV normal pero corriente baja

**Diagnóstico:**

```
┌─ ¿Voltaje PV < 50V?
│  └─ SÍ: No hay sol
│         Acción: Revisar hora, nubosidad
│
└─ ¿Voltaje PV normal pero Potencia baja?
   ├─ Revisar irradiancia (¿nublado?)
   ├─ Revisar paneles (¿sucios/sombra?)
   ├─ Revisar cableado PV (¿cortado?)
   ├─ Revisar inversor (¿falla de entrada?)
   └─ Revisar degradación acumulada
```

**Pasos de acción:**

1. Limpiar paneles (polvo, suciedad)
2. Revisar sombras (árboles, edificios)
3. Verificar cableado con multímetro
4. Comparar con inversor vecino
5. Solicitar service si persiste

---

### Problema 2: Batería No Carga

**Síntomas:**
- Voltaje batería no sube a pesar de panel activo
- Corriente de batería = 0A

**Diagnóstico:**

```
Causa Probable       | Verificación           | Solución
──────────────────────────────────────────────────────────
Voltaje muy alto     | ¿Volt Bat > 57V?       | Desconectar inversor
Temperatura fría     | ¿Temp < 0°C?           | Calentar batería
Batería defectuosa   | ¿Voltaje se cae?       | Reemplazar
Cableado suelto      | ¿Conexión sucia?       | Limpiar/apretar
Configuración        | ¿Habilitada carga PV?  | Revisar settings
```

---

### Problema 3: Voltaje AC Oscila

**Síntomas:**
- Luces parpadean
- Equipos se apagan/reinician
- Voltaje cambia rápidamente

**Causa Probable:**
- Carga muy variable (motor arrancando, etc)
- Batería débil
- Cableado de baja calidad

**Solución:**
1. Aumentar capacidad batería
2. Limitar corriente de carga variable
3. Mejorar cableado (sección más grande)

---

## 🔧 MEJORES PRÁCTICAS DE MANTENIMIENTO

### Checklist Mensual

```
□ Limpiar paneles (si polvo visible)
□ Revisar voltaje batería (¿dentro de rango?)
□ Revisar temperatura inversor (< 50°C)
□ Revisar alertas en dashboard
□ Verificar ventilación inversor (sin obstrucciones)
□ Revisar apretado de bornes (no debe haber corrosión)
```

### Checklist Trimestral

```
□ Análisis de eficiencia (comparar con mes anterior)
□ Revisar SOC máximo/mínimo alcanzado
□ Revisar ciclos de carga/descarga
□ Inspección visual de paneles (grietas, decoloración)
□ Teste de carga bajo carga máxima
```

### Checklist Anual

```
□ Evaluación de degradación (comparar con año anterior)
□ Análisis de performance ratio
□ Mantenimiento de batería (si batería abierta)
□ Limpieza a fondo de todo el sistema
□ Actualización firmware inversor
```

---

## 📐 CÁLCULOS DE EFICIENCIA

### Cálculo 1: Eficiencia Diaria

```python
def daily_efficiency(energy_in_pv_kwh, energy_out_ac_kwh):
    """
    Eficiencia del sistema = Energía salida / Energía entrada
    Típica: 90-95%
    """
    if energy_in_pv_kwh == 0:
        return 0
    return (energy_out_ac_kwh / energy_in_pv_kwh) * 100

# Ejemplo:
# Paneles generaron: 24 kWh en día
# Salida AC: 23.1 kWh
# Eficiencia = 23.1 / 24 * 100 = 96.25%
```

### Cálculo 2: Degradación Anual

```python
def annual_degradation(production_month1, production_month12):
    """
    Degradación anual = Pérdida promedio por mes
    Típica: 0.5-0.8% anual
    Alerta: > 1.5% anual
    """
    if production_month1 == 0:
        return 0
    
    total_loss = production_month1 - production_month12
    degradation = (total_loss / production_month1) * 100 / 12
    
    return degradation

# Ejemplo:
# Mes 1 (enero): 750 kWh
# Mes 12 (diciembre): 740 kWh
# Degradación = (750-740)/750 * 100 / 12 = 0.11% mensuales
```

### Cálculo 3: Autonomía de Batería

```python
def battery_autonomy_hours(battery_capacity_kwh, 
                          average_load_kw,
                          min_discharge_soc):
    """
    ¿Cuántas horas puedo vivir de batería sola?
    """
    usable_capacity = battery_capacity_kwh * (1 - min_discharge_soc/100)
    hours = usable_capacity / average_load_kw
    return hours

# Ejemplo:
# Batería 48V 100Ah = 4.8 kWh (teórico)
# Carga promedio: 1.5 kW
# SOC mínimo: 20%
# Usable = 4.8 * (1 - 0.2) = 3.84 kWh
# Autonomía = 3.84 / 1.5 = 2.56 horas
```

---

## 📊 ESPECIFICACIONES TÉCNICAS FELICITY

### Felicity 3KW (Típico)

```
ENTRADA PV:
  Voltaje máx: 450V DC
  Corriente máx: 45A
  Potencia nominal: 3000W
  MPPT range: 100-450V
  
SALIDA AC:
  Voltaje: 220-240V AC
  Frecuencia: 50 Hz ± 0.2Hz
  Potencia continua: 3000W
  Potencia pico: 5000W
  THD: < 5%
  
BATERÍA (compatibles):
  Voltaje: 48V nominal
  Capacidad: 50-200 Ah
  Corriente máx carga: 50A
  Corriente máx descarga: 100A
  Tipos: Litio, LiFePO4, AGM
  
CARACTERÍSTICAS:
  Eficiencia: 94-97%
  Peso: 45 kg
  Temperatura operación: -10 a +50°C
  Altitud máxima: 2000m
```

### Felicity 5KW (Típico)

```
ENTRADA PV:
  Voltaje máx: 500V DC
  Corriente máx: 60A
  Potencia nominal: 5000W
  
SALIDA AC:
  Voltaje: 220-240V AC (configurables)
  Potencia continua: 5000W
  Potencia pico: 8000W
  
BATERÍA:
  Voltaje: 48V o 96V
  Capacidad: 100-300 Ah
  Corriente máx carga: 80A
  Corriente máx descarga: 150A
  
CARACTERÍSTICAS:
  Eficiencia: 95-98%
  Peso: 65 kg
  Refrigeración: Ventilador automático
  Pantalla: Touch 5" TFT color
```

---

## 🎯 RESUMEN DE UMBRALES RECOMENDADOS

| Parámetro | Tipo | Warning | Alarm | Notas |
|-----------|------|---------|-------|-------|
| Voltaje Batería | 48V | 45V | 40V | Sistema offline si < 38V |
| Corriente Batería | A | 180A | 200A | Máxima carga/descarga |
| SOC | % | 25% | 10% | Rango óptimo 40-80% |
| Temperatura | °C | 45°C | 50°C | Acelerada degradación > 40°C |
| Eficiencia | % | < 92% | < 90% | Degradación normal < 94% |
| Uptime | % | < 98% | < 95% | Objetivo > 99.5% |
| Voltaje AC | V | 250 | 270 | Nominal 240V ±5% |
| Frecuencia | Hz | > 50.5 | > 51 | Nominal 50Hz ± 0.2Hz |
| Potencia PV | W | N/A | < 10% nominal | Verificar con irradiancia |

---

**Documento preparado con estándares internacionales de energía solar**  
**Versión:** 1.0 - Mayo 2024
